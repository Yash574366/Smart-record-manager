"""Central place for figuring out 'where is the app running from'.

This matters because there are two very different situations:

1. Running from source (``python -m app.main``) - the app lives in the
   project folder, so data/backups/resources sit next to that folder as
   they always have.
2. Running as a PyInstaller-built standalone .exe (``--onefile``) - the
   .exe unpacks itself into a temporary folder on every launch
   (``sys._MEIPASS``), which is deleted afterwards. If data/backups were
   written there, every restart would look like a fresh install and wipe
   the customer's records. Persistent folders (data/, backups/) must
   instead live next to the actual .exe file, not the temp extraction
   folder - while read-only bundled resources (icons) are fine to read
   from the temp folder since they're bundled at build time.

Nothing about the app's behavior changes when run from source; these
helpers just make the same folder layout also correct when frozen.
"""
import os
import sys


def is_frozen() -> bool:
    """True when running as a PyInstaller-built executable."""
    return bool(getattr(sys, "frozen", False))


def get_persistent_base_dir() -> str:
    """Folder where data/backups should live - always writable and always
    the SAME folder across restarts, whether running from source or as a
    built .exe."""
    if is_frozen():
        return os.path.dirname(sys.executable)
    # app/utils/paths.py -> app/ -> project root
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def get_resource_base_dir() -> str:
    """Folder to look up bundled read-only resources (icons, etc.) from.
    When frozen, PyInstaller extracts --add-data files under sys._MEIPASS;
    otherwise it's the same project root as above."""
    if is_frozen():
        return getattr(sys, "_MEIPASS", get_persistent_base_dir())
    return get_persistent_base_dir()
