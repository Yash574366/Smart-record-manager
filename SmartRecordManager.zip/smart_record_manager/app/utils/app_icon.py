"""Looks for a custom app icon so both the QApplication (taskbar) and
individual windows can use it. See README.md -> 'Setting a custom app icon'
for how to add your own."""
import os

from PySide6.QtGui import QIcon

from app.utils.paths import get_resource_base_dir

ICON_DIR = os.path.join(get_resource_base_dir(), "resources", "icons")


def load_app_icon() -> QIcon | None:
    for filename in ("app_icon.ico", "app_icon.png"):
        path = os.path.join(ICON_DIR, filename)
        if os.path.exists(path):
            return QIcon(path)
    return None
