"""Password hashing helpers (PBKDF2-HMAC-SHA256, stdlib only - no extra deps)."""
import hashlib
import os
import hmac


def hash_password(password: str, salt: str = None) -> tuple[str, str]:
    """Returns (hash_hex, salt_hex). Generates a new salt if none given."""
    if salt is None:
        salt_bytes = os.urandom(16)
        salt = salt_bytes.hex()
    else:
        salt_bytes = bytes.fromhex(salt)

    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt_bytes, 200_000)
    return dk.hex(), salt


def verify_password(password: str, stored_hash: str, salt: str) -> bool:
    computed_hash, _ = hash_password(password, salt)
    return hmac.compare_digest(computed_hash, stored_hash)
