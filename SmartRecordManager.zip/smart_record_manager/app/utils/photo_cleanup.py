"""
Deletes photo FILES older than N days from the app's photos folder to keep
disk usage predictable over years of use. This never touches the database -
Record.photo_data keeps a durable copy, so the app can still display the
photo and offer a "Download Photo" button even after the file is gone.
"""
import os
import time

from app.utils.photo_store import PHOTOS_DIR

DEFAULT_PHOTO_RETENTION_DAYS = 30


def purge_old_photo_files(older_than_days: int = DEFAULT_PHOTO_RETENTION_DAYS) -> int:
    if not os.path.isdir(PHOTOS_DIR):
        return 0

    cutoff = time.time() - (older_than_days * 86400)
    deleted = 0
    for filename in os.listdir(PHOTOS_DIR):
        path = os.path.join(PHOTOS_DIR, filename)
        try:
            if os.path.isfile(path) and os.path.getmtime(path) < cutoff:
                os.remove(path)
                deleted += 1
        except OSError:
            pass  # file in use / permissions - skip, try again next launch
    return deleted
