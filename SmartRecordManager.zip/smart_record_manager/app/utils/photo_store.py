"""
Centralizes how record photos are stored and retrieved.

Storage model:
  - Every photo (uploaded or camera-captured) is resized/compressed and
    copied into PHOTOS_DIR so it lives in one predictable place inside the
    app folder, AT A SENSIBLE SIZE - a full-resolution camera photo (often
    3-8 MB) is shrunk to a max of 900px on its longest side, saved as JPEG
    quality 82. This is still perfectly clear for viewing/printing a profile
    photo, but roughly 10-20x smaller than the original.
  - A durable copy of the *same compressed* bytes is also saved in the
    database (Record.photo_data), so the photo can still be viewed/
    downloaded even after the on-disk file is auto-deleted (see the 30-day
    cleanup in photo_cleanup.py). Because it's the compressed version, every
    backup of the database stays small too - this is what keeps 5 years of
    daily photos from turning every backup into a multi-gigabyte file.
  - Display code should always try the disk file first (fast, no DB read)
    and fall back to the database copy if the file is missing.
"""
import io
import os
import uuid

from PySide6.QtGui import QPixmap
from PySide6.QtCore import Qt

from app.utils.paths import get_persistent_base_dir

PROJECT_ROOT = get_persistent_base_dir()
PHOTOS_DIR = os.path.join(PROJECT_ROOT, "data", "photos")

MAX_DIMENSION = 900     # longest side, in pixels
JPEG_QUALITY = 82


def ensure_photos_dir():
    os.makedirs(PHOTOS_DIR, exist_ok=True)


def _compress_image(source_path: str) -> bytes:
    """Resizes to MAX_DIMENSION and re-encodes as JPEG. Falls back to the
    original raw bytes if Pillow can't read the file for any reason (e.g. an
    unusual format), so a photo is never lost just because compression failed."""
    try:
        from PIL import Image, ImageOps
        with Image.open(source_path) as img:
            img = ImageOps.exif_transpose(img)  # respect phone/camera rotation metadata
            if img.mode not in ("RGB", "L"):
                img = img.convert("RGB")
            img.thumbnail((MAX_DIMENSION, MAX_DIMENSION), Image.LANCZOS)
            buffer = io.BytesIO()
            img.save(buffer, format="JPEG", quality=JPEG_QUALITY, optimize=True)
            return buffer.getvalue()
    except Exception:
        with open(source_path, "rb") as f:
            return f.read()


def store_photo_file(source_path: str) -> tuple[str, bytes]:
    """Compresses the photo and saves it into PHOTOS_DIR (replacing a fresh
    camera capture in place, or writing a new file for an uploaded photo),
    returning (new_path, compressed_bytes)."""
    ensure_photos_dir()
    source_path = os.path.abspath(source_path)
    compressed = _compress_image(source_path)

    if os.path.dirname(source_path) == os.path.abspath(PHOTOS_DIR):
        dest_path = os.path.splitext(source_path)[0] + ".jpg"
    else:
        dest_path = os.path.join(PHOTOS_DIR, f"{uuid.uuid4().hex}.jpg")

    with open(dest_path, "wb") as f:
        f.write(compressed)

    return dest_path, compressed


def load_pixmap_for_record(record, size: int = None) -> QPixmap:
    """Returns a QPixmap for this record's photo - from the on-disk file if
    it still exists, otherwise from the durable database copy. Returns a
    null QPixmap if there's no photo at all."""
    pixmap = QPixmap()
    if record.photo_path and os.path.exists(record.photo_path):
        pixmap = QPixmap(record.photo_path)
    elif record.photo_data:
        pixmap = QPixmap()
        pixmap.loadFromData(record.photo_data)

    if not pixmap.isNull() and size:
        pixmap = pixmap.scaled(size, size, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        x = max(0, (pixmap.width() - size) // 2)
        y = max(0, (pixmap.height() - size) // 2)
        pixmap = pixmap.copy(x, y, size, size)

    return pixmap


def has_any_photo(record) -> bool:
    return bool(record.photo_data) or bool(record.photo_path)


def photo_file_exists_on_disk(record) -> bool:
    return bool(record.photo_path) and os.path.exists(record.photo_path)
