"""
Maintains data/user_credentials_backup.txt - a plain-text copy of every
username + password so an admin who forgets a password can look it up
without needing a "forgot password" flow.

SECURITY NOTE: this file stores passwords in PLAIN TEXT, unlike the actual
login system (which uses salted PBKDF2 hashes and never stores the raw
password). Anyone who can open this file can log in as any user in it.
This was added at the customer's explicit request for convenience - keep
this file in a private location, and treat it like a password itself.
"""
import os


def upsert_credential(credentials_file: str, username: str, password: str):
    if not credentials_file:
        return
    try:
        entries = {}
        if os.path.exists(credentials_file):
            with open(credentials_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#") or ":" not in line:
                        continue
                    u, p = line.split(":", 1)
                    entries[u.strip()] = p.strip()

        entries[username] = password

        os.makedirs(os.path.dirname(credentials_file), exist_ok=True)
        with open(credentials_file, "w", encoding="utf-8") as f:
            f.write("# Smart Record Manager - saved login credentials\n")
            f.write("# SECURITY WARNING: passwords below are stored in PLAIN TEXT.\n")
            f.write("# Keep this file private - anyone who reads it can log in as these users.\n\n")
            for u, p in entries.items():
                f.write(f"{u}: {p}\n")
    except OSError:
        pass  # never let a credentials-file write failure block login/account actions


def remove_credential(credentials_file: str, username: str):
    if not credentials_file or not os.path.exists(credentials_file):
        return
    try:
        entries = {}
        with open(credentials_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or ":" not in line:
                    continue
                u, p = line.split(":", 1)
                if u.strip() != username:
                    entries[u.strip()] = p.strip()
        with open(credentials_file, "w", encoding="utf-8") as f:
            f.write("# Smart Record Manager - saved login credentials\n")
            f.write("# SECURITY WARNING: passwords below are stored in PLAIN TEXT.\n")
            f.write("# Keep this file private - anyone who reads it can log in as these users.\n\n")
            for u, p in entries.items():
                f.write(f"{u}: {p}\n")
    except OSError:
        pass
