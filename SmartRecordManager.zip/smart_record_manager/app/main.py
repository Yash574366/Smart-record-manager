"""
Smart Record Manager - Entry point
Run with:  python -m app.main   (from the project root)
"""
import os
import sys

from PySide6.QtWidgets import QApplication, QMessageBox
from PySide6.QtCore import QSharedMemory

from app.models.bootstrap import bootstrap_database
from app.controllers.auth_controller import AuthController
from app.controllers.category_controller import CategoryController
from app.controllers.record_controller import RecordController
from app.ui.login_dialog import LoginDialog
from app.ui.main_window import MainWindow
from app.utils.app_icon import load_app_icon
from app.utils.paths import get_persistent_base_dir

PROJECT_ROOT = get_persistent_base_dir()
DATA_DIR = os.path.join(PROJECT_ROOT, "data")
BACKUP_DIR = os.path.join(PROJECT_ROOT, "backups")
DB_PATH = os.path.join(DATA_DIR, "records.db")
CREDENTIALS_FILE = os.path.join(DATA_DIR, "user_credentials_backup.txt")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(BACKUP_DIR, exist_ok=True)

_app = None
_window = None

# A unique, fixed name so every launch of this app (however it's started -
# RUN_APP.bat, double-clicking the .exe, or running `python -m app.main`
# directly from the folder) checks the SAME shared-memory slot. This is
# what makes "already open" detection work regardless of how it was opened.
_SINGLE_INSTANCE_KEY = "SmartRecordManager_SingleInstanceLock_v1"
_single_instance_guard = None  # kept alive for the whole process lifetime


def _acquire_single_instance_lock() -> bool:
    """Returns True if this is the only running instance. If another
    instance already holds the lock, returns False - the caller should show
    a message and exit rather than opening a second window onto the same
    database (two windows both writing to records.db is exactly what was
    corrupting data/desyncing changes before this fix)."""
    global _single_instance_guard
    _single_instance_guard = QSharedMemory(_SINGLE_INSTANCE_KEY)

    # Defensive cleanup: on some platforms a crashed instance can leave a
    # stale segment behind. Attaching-then-detaching releases it if nothing
    # is really holding it, so a genuinely stale lock doesn't block forever.
    if _single_instance_guard.attach():
        _single_instance_guard.detach()

    if not _single_instance_guard.create(1):
        return False  # another live instance is holding this segment right now
    return True


def restart_login():
    """Called from MainWindow.logout() to bring back the login screen
    without restarting the whole process."""
    launch()


def launch():
    global _window

    engine, Session = bootstrap_database(DB_PATH, CREDENTIALS_FILE)
    session = Session()

    auth = AuthController(session, credentials_file=CREDENTIALS_FILE)
    login_dialog = LoginDialog(auth, org_name="Smart Record Manager")

    if login_dialog.exec():
        record_controller = RecordController(session)
        category_controller = CategoryController(session)
        _window = MainWindow(session, record_controller, category_controller, auth,
                              DB_PATH, BACKUP_DIR)
        _window.showMaximized()
    else:
        # user closed the login dialog
        if _app is not None and _window is None:
            sys.exit(0)


def main():
    global _app
    _app = QApplication(sys.argv)

    icon = load_app_icon()
    if icon:
        _app.setWindowIcon(icon)

    if not _acquire_single_instance_lock():
        QMessageBox.warning(
            None, "Already Running",
            "Smart Record Manager is already open.\n\n"
            "Please use the existing window instead of opening a new one - "
            "having it open twice at once can cause changes made in one "
            "window to conflict with the other."
        )
        sys.exit(0)

    launch()
    sys.exit(_app.exec())


if __name__ == "__main__":
    main()
