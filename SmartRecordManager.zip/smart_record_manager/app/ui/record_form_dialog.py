import os

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QHBoxLayout, QLineEdit, QComboBox,
    QDateEdit, QSpinBox, QCheckBox, QTextEdit, QPushButton, QLabel,
    QFileDialog, QMessageBox, QScrollArea, QWidget
)
from PySide6.QtCore import QDate, Qt

from app.models.models import FieldType
from app.utils.photo_store import PHOTOS_DIR, store_photo_file, has_any_photo


class RecordFormDialog(QDialog):
    """Builds form inputs dynamically from the category's FieldDef list.
    Works identically whether the category is Students, Patients, Books, or
    anything else the admin defined - this is the payoff of the EAV schema."""

    def __init__(self, category, record_controller, existing_record=None, parent=None):
        super().__init__(parent)
        self.category = category
        self.rc = record_controller
        self.record = existing_record
        self.inputs = {}          # field_id -> widget
        # Path of a NEWLY picked/captured photo this session (None = keep
        # whatever the record already has, if editing)
        self.new_photo_source_path = None
        display_path = existing_record.photo_path if existing_record else None

        self.setWindowTitle(
            f"{'Edit' if existing_record else 'Add'} {category.name[:-1] if category.name.endswith('s') else category.name} Record"
        )
        self.setMinimumWidth(480)

        outer = QVBoxLayout(self)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        form_container = QWidget()
        self.form_layout = QFormLayout(form_container)
        self.form_layout.setSpacing(12)
        scroll.setWidget(form_container)
        outer.addWidget(scroll, stretch=1)

        existing_values = {}
        if existing_record:
            existing_values = {fv.field_id: fv.value for fv in existing_record.field_values}

        # Photo upload - only for categories that have it enabled
        if category.has_photo:
            photo_row = QHBoxLayout()
            self.photo_label = QLabel(display_path or "No photo selected")
            photo_btn = QPushButton("Upload Photo")
            photo_btn.setObjectName("SecondaryButton")
            photo_btn.clicked.connect(self.pick_photo)
            camera_btn = QPushButton("📷 Take Photo")
            camera_btn.setObjectName("SecondaryButton")
            camera_btn.clicked.connect(self.take_photo)
            photo_row.addWidget(self.photo_label, stretch=1)
            photo_row.addWidget(photo_btn)
            photo_row.addWidget(camera_btn)

            # Only offered when editing a record that actually has a photo -
            # covers the case where the on-disk file was auto-cleaned after 30
            # days but the app still has a durable copy in the database.
            if existing_record and has_any_photo(existing_record):
                download_btn = QPushButton("⬇ Download Photo")
                download_btn.setObjectName("SecondaryButton")
                download_btn.clicked.connect(self.download_photo)
                photo_row.addWidget(download_btn)

            self.form_layout.addRow("Photo", photo_row)

        # Dynamic fields, in sort order
        for field in sorted(category.fields, key=lambda f: f.sort_order):
            widget = self._build_input(field, existing_values.get(field.id))
            self.inputs[field.id] = widget
            label_text = field.name + (" *" if field.is_required else "")
            self.form_layout.addRow(label_text, widget)

        # Buttons
        btn_row = QHBoxLayout()
        back_btn = QPushButton("Back")
        back_btn.setObjectName("SecondaryButton")
        back_btn.clicked.connect(self.reject)
        save_btn = QPushButton("Save Record")
        save_btn.setObjectName("PrimaryButton")
        save_btn.clicked.connect(self.save)
        btn_row.addStretch()
        btn_row.addWidget(back_btn)
        btn_row.addWidget(save_btn)
        outer.addLayout(btn_row)

    # ------------------------------------------------------------------
    def _build_input(self, field, current_value):
        ft = field.field_type
        if ft == FieldType.NUMBER:
            w = QLineEdit()
            w.setPlaceholderText("Number")
            if current_value:
                w.setText(str(current_value))
            return w
        if ft == FieldType.DATE:
            w = QDateEdit()
            w.setCalendarPopup(True)
            w.setDisplayFormat("yyyy-MM-dd")
            if current_value:
                try:
                    w.setDate(QDate.fromString(current_value, "yyyy-MM-dd"))
                except Exception:
                    w.setDate(QDate.currentDate())
            else:
                w.setDate(QDate.currentDate())
            return w
        if ft == FieldType.DROPDOWN:
            w = QComboBox()
            options = (field.dropdown_options or "").split(",")
            w.addItems([o.strip() for o in options if o.strip()])
            if current_value:
                idx = w.findText(current_value)
                if idx >= 0:
                    w.setCurrentIndex(idx)
            return w
        if ft == FieldType.CHECKBOX:
            w = QCheckBox()
            w.setChecked(str(current_value).lower() in ("true", "1", "yes"))
            return w
        if ft == FieldType.LONG_TEXT:
            w = QTextEdit()
            w.setMaximumHeight(80)
            if current_value:
                w.setPlainText(current_value)
            return w
        if ft in (FieldType.IMAGE, FieldType.FILE):
            # Simple file-path picker; stored as a path string in FieldValue
            container = QWidget()
            row = QHBoxLayout(container)
            row.setContentsMargins(0, 0, 0, 0)
            path_label = QLabel(current_value or "No file selected")
            pick_btn = QPushButton("Choose File")
            pick_btn.setObjectName("SecondaryButton")

            def choose():
                path, _ = QFileDialog.getOpenFileName(self, f"Select {field.name}")
                if path:
                    path_label.setText(path)
                    path_label.setProperty("file_path", path)

            pick_btn.clicked.connect(choose)
            path_label.setProperty("file_path", current_value or "")
            row.addWidget(path_label, stretch=1)
            row.addWidget(pick_btn)
            container._path_label = path_label  # keep reference for extraction
            return container
        # TEXT, EMAIL, PHONE default to a line edit
        w = QLineEdit()
        if current_value:
            w.setText(current_value)
        return w

    def _extract_value(self, field, widget):
        ft = field.field_type
        if ft == FieldType.DATE:
            return widget.date().toString("yyyy-MM-dd")
        if ft == FieldType.DROPDOWN:
            return widget.currentText()
        if ft == FieldType.CHECKBOX:
            return "true" if widget.isChecked() else "false"
        if ft == FieldType.LONG_TEXT:
            return widget.toPlainText()
        if ft in (FieldType.IMAGE, FieldType.FILE):
            return widget._path_label.property("file_path") or ""
        return widget.text()

    def pick_photo(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select Photo", filter="Images (*.png *.jpg *.jpeg)")
        if path:
            self.new_photo_source_path = path
            self.photo_label.setText(path)

    def take_photo(self):
        try:
            from app.ui.camera_capture_dialog import CameraCaptureDialog
        except ImportError as e:
            QMessageBox.critical(
                self, "Camera feature unavailable",
                "The camera feature needs the PySide6 multimedia components, "
                f"which weren't found: {e}\n\nTry reinstalling with: "
                "pip install -r requirements.txt"
            )
            return

        dialog = CameraCaptureDialog(PHOTOS_DIR, parent=self)
        if dialog.exec() and dialog.captured_path:
            self.new_photo_source_path = dialog.captured_path
            self.photo_label.setText(dialog.captured_path)

    def download_photo(self):
        if not self.record:
            return
        default_name = f"photo_record_{self.record.id}.jpg"
        save_path, _ = QFileDialog.getSaveFileName(self, "Save Photo As", default_name,
                                                     "Images (*.jpg *.jpeg *.png)")
        if not save_path:
            return
        try:
            if self.record.photo_data:
                with open(save_path, "wb") as f:
                    f.write(self.record.photo_data)
            elif self.record.photo_path and os.path.exists(self.record.photo_path):
                with open(self.record.photo_path, "rb") as src, open(save_path, "wb") as dst:
                    dst.write(src.read())
            else:
                QMessageBox.warning(self, "No photo available",
                                     "This record doesn't have a recoverable photo.")
                return
            QMessageBox.information(self, "Saved", f"Photo saved to {save_path}")
        except OSError as e:
            QMessageBox.critical(self, "Download failed", str(e))

    def save(self):
        values = {}
        missing = []
        for field in self.category.fields:
            widget = self.inputs[field.id]
            value = self._extract_value(field, widget)
            if field.is_required and not str(value).strip():
                missing.append(field.name)
            values[field.id] = value

        if missing:
            QMessageBox.warning(self, "Missing required fields",
                                 "Please fill in: " + ", ".join(missing))
            return

        photo_path, photo_data = None, None
        if self.new_photo_source_path:
            try:
                photo_path, photo_data = store_photo_file(self.new_photo_source_path)
            except OSError as e:
                QMessageBox.critical(self, "Photo save failed", str(e))
                return

        try:
            if self.record:
                self.rc.update_record(self.record, values, photo_path=photo_path, photo_data=photo_data)
            else:
                self.rc.create_record(self.category, values, photo_path=photo_path, photo_data=photo_data)
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Save failed", str(e))
