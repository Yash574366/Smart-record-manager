import os

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QPushButton, QLabel,
    QStackedWidget, QButtonGroup, QFileDialog, QMessageBox, QMenu, QToolButton,
    QFrame
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap

from app.models.models import OrgSettings, Category
from app.ui.styles import build_stylesheet
from app.ui.dashboard_widget import DashboardWidget
from app.ui.record_list_widget import RecordListWidget
from app.ui.category_manager_dialog import CategoryManagerDialog
from app.ui.settings_dialog import SettingsDialog
from app.ui.recycle_bin_dialog import RecycleBinDialog, RETENTION_DAYS
from app.controllers.io_controller import IOController
from app.controllers.backup_controller import BackupController
from app.controllers import incremental_backup
from app.ui.restore_backup_dialog import RestoreBackupDialog
from app.ui.backup_settings_dialog import BackupSettingsDialog
from app.utils.app_icon import load_app_icon


def make_square_pixmap(path: str, size: int) -> QPixmap:
    """Loads an image and returns a perfectly square, undistorted crop of it
    at `size`x`size` - scales to cover the square first, then crops the
    center, instead of stretching a non-square image to fit."""
    source = QPixmap(path)
    if source.isNull():
        return source
    scaled = source.scaled(size, size, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
    x = max(0, (scaled.width() - size) // 2)
    y = max(0, (scaled.height() - size) // 2)
    return scaled.copy(x, y, size, size)


class MainWindow(QMainWindow):
    def __init__(self, session, record_controller, category_controller, auth_controller,
                 db_path, backup_dir):
        super().__init__()
        self.session = session
        self.rc = record_controller
        self.cc = category_controller
        self.auth = auth_controller
        self.io = IOController(session, record_controller, category_controller)
        self.org_settings = session.query(OrgSettings).first()
        self.backup = BackupController(db_path, backup_dir, org_settings=self.org_settings)
        self.setWindowTitle(f"{self.org_settings.organization_name} - Smart Record Manager")
        icon = load_app_icon()
        if icon:
            self.setWindowIcon(icon)
        self.resize(1240, 780)

        # Purge anything that's been in the Recycle Bin past its retention window
        self.rc.empty_recycle_bin(older_than_days=RETENTION_DAYS)
        # Free disk space: old photo files (DB keeps a durable backup copy)
        # and old backup files (a fresh one is always made on schedule)
        from app.utils.photo_cleanup import purge_old_photo_files
        purge_old_photo_files(older_than_days=30)
        self.backup.purge_old_auto_backups(older_than_days=self.org_settings.backup_retention_days or 180)

        self.apply_theme()
        self._build_ui()
        # Automatic backups are INCREMENTAL - each one only contains records
        # added/changed since the last one, so backup size tracks daily
        # activity instead of the whole (ever-growing) database every time.
        # For a complete archive of everything, use Menu -> Backup -> Backup
        # All Records.
        incremental_backup.incremental_backup_if_due(
            self.session, self.cc, self.rc, self.backup,
            interval_hours=self.org_settings.backup_frequency_hours or 24
        )

    # ------------------------------------------------------------------
    def apply_theme(self):
        self.setStyleSheet(build_stylesheet(
            self.org_settings.theme, self.org_settings.theme_color, self.org_settings.font_size
        ))

    def _build_ui(self, keep_page_category_id=None):
        """Builds (or rebuilds) the entire sidebar + page stack. Safe to call
        again at runtime - e.g. after categories/fields change - so the app
        never needs a restart to reflect admin changes."""
        central = QWidget()
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        self.setCentralWidget(central)

        # ---- Sidebar ----
        sidebar = QWidget()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(232)
        sb_layout = QVBoxLayout(sidebar)
        sb_layout.setContentsMargins(14, 20, 14, 20)
        sb_layout.setSpacing(4)

        # Org branding block: square logo (if set) + name
        brand_row = QHBoxLayout()
        brand_row.setSpacing(10)
        if self.org_settings.logo_path and os.path.exists(self.org_settings.logo_path):
            logo_frame = QFrame()
            logo_frame.setObjectName("LogoFrame")
            logo_frame.setFixedSize(48, 48)
            logo_layout = QVBoxLayout(logo_frame)
            logo_layout.setContentsMargins(3, 3, 3, 3)
            logo_label = QLabel()
            pixmap = make_square_pixmap(self.org_settings.logo_path, 42)
            if not pixmap.isNull():
                logo_label.setPixmap(pixmap)
            logo_label.setFixedSize(42, 42)
            logo_layout.addWidget(logo_label)
            brand_row.addWidget(logo_frame)

        org_label = QLabel(self.org_settings.organization_name)
        org_label.setObjectName("BrandLabel")
        org_label.setWordWrap(True)
        brand_row.addWidget(org_label, stretch=1)
        sb_layout.addLayout(brand_row)
        sb_layout.addSpacing(12)

        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)

        dashboard_btn = self._make_nav_button("📊  Dashboard")
        sb_layout.addWidget(dashboard_btn)

        self.category_buttons = {}
        for cat in self.cc.list_categories():
            btn = self._make_nav_button(f"📁  {cat.name}")
            sb_layout.addWidget(btn)
            self.category_buttons[cat.id] = btn

        sb_layout.addSpacing(10)

        if self.auth.can_manage_fields():
            manage_btn = QPushButton("⚙  Manage Categories")
            manage_btn.setObjectName("SecondaryButton")
            manage_btn.clicked.connect(self.open_category_manager)
            sb_layout.addWidget(manage_btn)

        if self.auth.can_delete():
            recycle_btn = QPushButton("🗑  Recycle Bin")
            recycle_btn.setObjectName("SecondaryButton")
            recycle_btn.clicked.connect(self.open_recycle_bin)
            sb_layout.addWidget(recycle_btn)

        sb_layout.addStretch()

        logout_btn = QPushButton("Logout")
        logout_btn.setObjectName("SecondaryButton")
        logout_btn.clicked.connect(self.logout)
        sb_layout.addWidget(logout_btn)

        root.addWidget(sidebar)

        # ---- Main area (top bar + stacked pages) ----
        main_area = QWidget()
        main_layout = QVBoxLayout(main_area)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        top_bar = QWidget()
        top_bar.setObjectName("TopBar")
        top_bar.setFixedHeight(58)
        top_layout = QHBoxLayout(top_bar)
        top_layout.setContentsMargins(24, 0, 24, 0)
        user_label = QLabel(f"👤 {self.auth.current_user.username} ({self.auth.current_user.role.value})")
        user_label.setObjectName("UserLabel")
        top_layout.addWidget(user_label)
        top_layout.addStretch()

        menu_btn = QToolButton()
        menu_btn.setText("Menu ▾")
        menu_btn.setObjectName("MenuButton")
        menu = QMenu(menu_btn)
        menu.addAction("Export Excel", lambda: self.export_current("excel"))
        menu.addAction("Export PDF", lambda: self.export_current("pdf"))
        menu.addAction("Export JSON", lambda: self.export_current("json"))
        menu.addSeparator()

        backup_menu = menu.addMenu("Backup")
        backup_menu.addAction("Backup All Records", self.manual_full_backup)
        backup_menu.addAction("Restore Backup...", self.open_restore_backup)
        backup_menu.addAction("Backup Settings", self.open_backup_settings)

        menu.addAction("Settings", self.open_settings)
        menu_btn.setMenu(menu)
        menu_btn.setPopupMode(QToolButton.InstantPopup)
        top_layout.addWidget(menu_btn)

        main_layout.addWidget(top_bar)

        self.stack = QStackedWidget()
        main_layout.addWidget(self.stack, stretch=1)

        self.dashboard = DashboardWidget(self.rc, self.org_settings.theme_color)
        self.stack.addWidget(self.dashboard)
        dashboard_btn.clicked.connect(lambda: self.stack.setCurrentWidget(self.dashboard))

        self.category_pages = {}
        target_page = self.dashboard
        for cat in self.cc.list_categories():
            page = RecordListWidget(cat, self.rc, self.auth, on_change=self.dashboard.refresh)
            self.stack.addWidget(page)
            self.category_pages[cat.id] = page
            self.category_buttons[cat.id].clicked.connect(
                lambda checked, p=page: self.stack.setCurrentWidget(p)
            )
            if keep_page_category_id and cat.id == keep_page_category_id:
                target_page = page

        if target_page is self.dashboard:
            dashboard_btn.setChecked(True)
        elif keep_page_category_id in self.category_buttons:
            self.category_buttons[keep_page_category_id].setChecked(True)
        self.stack.setCurrentWidget(target_page)

        root.addWidget(main_area, stretch=1)

    def _make_nav_button(self, text):
        btn = QPushButton(text)
        btn.setObjectName("SidebarButton")
        btn.setCheckable(True)
        btn.setMinimumHeight(40)
        self.nav_group.addButton(btn)
        return btn

    # ------------------------------------------------------------------
    def current_category(self):
        for cat_id, page in self.category_pages.items():
            if page == self.stack.currentWidget():
                return page.category
        return None

    def export_current(self, fmt):
        cat = self.current_category()
        if not cat:
            QMessageBox.information(self, "Select a category", "Open a category page first.")
            return
        ext_map = {"csv": "CSV Files (*.csv)", "excel": "Excel Files (*.xlsx)",
                   "pdf": "PDF Files (*.pdf)", "json": "JSON Files (*.json)"}
        default_ext = {"csv": ".csv", "excel": ".xlsx", "pdf": ".pdf", "json": ".json"}[fmt]
        path, _ = QFileDialog.getSaveFileName(self, "Export", f"{cat.name}{default_ext}", ext_map[fmt])
        if not path:
            return
        try:
            getattr(self.io, f"export_{fmt}")(cat, path)
            QMessageBox.information(self, "Export complete", f"Exported to {path}")
        except ImportError as e:
            QMessageBox.critical(self, "Missing dependency",
                                  f"Install the required package (see requirements.txt): {e}")
        except Exception as e:
            QMessageBox.critical(self, "Export failed", str(e))

    def manual_full_backup(self):
        path = self.backup.create_full_backup(label="backup_all")
        QMessageBox.information(
            self, "Full backup complete",
            f"Everything (old and new records) saved to:\n{path}\n\n"
            "This is the one to use if you're archiving before retiring this computer. "
            "Your login username/password are never included in any backup."
        )

    def open_backup_settings(self):
        dialog = BackupSettingsDialog(self.session, self.org_settings, parent=self)
        dialog.exec()

    def open_restore_backup(self):
        dialog = RestoreBackupDialog(self.backup, self.cc, self.rc, parent=self)
        result = dialog.exec()
        if result and dialog.result_kind == "incremental":
            # Incremental restores merge into the live, already-open database -
            # just refresh the UI, no restart needed.
            for page in self.category_pages.values():
                page.refresh()
            self.dashboard.refresh()
        elif result and dialog.result_kind == "full":
            QMessageBox.information(
                self, "Restore complete",
                "The backup has been restored. The app will now close - "
                "please reopen it (e.g. double-click RUN_APP.bat) to load the restored data."
            )
            import sys
            self.close()
            sys.exit(0)

    def open_category_manager(self):
        current_cat = self.current_category()
        dialog = CategoryManagerDialog(self.cc, parent=self)
        dialog.exec()
        # Live refresh - no restart needed. Try to stay on the same category
        # page if it still exists after the edits.
        self._build_ui(keep_page_category_id=current_cat.id if current_cat else None)

    def open_recycle_bin(self):
        dialog = RecycleBinDialog(self.rc, parent=self)
        dialog.exec()
        # Restoring a record can affect any category page + the dashboard
        for page in self.category_pages.values():
            page.refresh()
        self.dashboard.refresh()

    def open_settings(self):
        dialog = SettingsDialog(self.session, self.org_settings, self.auth,
                                 on_theme_change=self.apply_theme, parent=self)
        dialog.exec()

        # If the admin renamed/changed their own account, current_user needs
        # to be re-fetched so the top bar doesn't keep showing the old name.
        if self.auth.current_user:
            from app.models.models import User
            self.auth.current_user = self.session.get(User, self.auth.current_user.id)

        self.setWindowTitle(f"{self.org_settings.organization_name} - Smart Record Manager")
        # Logo or org name may have changed - rebuild the sidebar to reflect it
        current_cat = self.current_category()
        self._build_ui(keep_page_category_id=current_cat.id if current_cat else None)

    def logout(self):
        self.auth.logout()
        self.close()
        # main.py handles re-showing the login dialog and a fresh MainWindow
        from app.main import restart_login
        restart_login()
