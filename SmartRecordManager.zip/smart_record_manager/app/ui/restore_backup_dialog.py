from datetime import datetime

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem,
    QPushButton, QLabel, QMessageBox
)
from PySide6.QtCore import Qt

from app.controllers.incremental_backup import is_incremental_backup, restore_incremental_backup


def _friendly_label(filename: str, kind: str) -> str:
    """FullBackup_2026-07-15_03-30PM.zip -> 'Full archive — Jul 15, 2026 3:30 PM'"""
    tag = "Full archive" if kind == "manual" else "New/updated profiles"
    try:
        base = filename.removesuffix(".zip").removesuffix(".db")
        parts = base.split("_")
        date_str, time_str = parts[-2], parts[-1]
        for fmt_date, fmt_time in (("%Y-%m-%d", "%I-%M%p"), ("%Y%m%d", "%H%M%S")):
            try:
                dt = datetime.strptime(f"{date_str}_{time_str}", f"{fmt_date}_{fmt_time}")
                return f"{tag} — {dt.strftime('%b %d, %Y %I:%M %p')}"
            except ValueError:
                continue
        return f"{tag} — {filename}"
    except Exception:
        return f"{tag} — {filename}"


class RestoreBackupDialog(QDialog):
    def __init__(self, backup_controller, category_controller, record_controller, parent=None):
        super().__init__(parent)
        self.backup = backup_controller
        self.cc = category_controller
        self.rc = record_controller
        self.result_kind = None  # "incremental" or "full", read by MainWindow after exec()
        self.setWindowTitle("Restore Backup")
        self.resize(540, 460)

        outer = QVBoxLayout(self)

        info = QLabel(
            "Select a backup to restore.\n\n"
            "\u2022 \"New/updated profiles\" backups MERGE those records into what's "
            "already here - matching by ID where possible, updating only if the "
            "backup's copy is newer, never duplicating.\n"
            "\u2022 \"Full archive\" backups REPLACE everything with that snapshot "
            "(a safety copy is made first). Your login username/password are "
            "never affected either way."
        )
        info.setWordWrap(True)
        outer.addWidget(info)

        location_label = QLabel(f"Backup folder: {self.backup.backup_root}")
        location_label.setStyleSheet("color: #64748B; font-size: 8pt;")
        location_label.setWordWrap(True)
        outer.addWidget(location_label)

        self.list_widget = QListWidget()
        outer.addWidget(self.list_widget, stretch=1)
        self.reload_backups()

        btn_row = QHBoxLayout()
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setObjectName("SecondaryButton")
        cancel_btn.clicked.connect(self.reject)
        restore_btn = QPushButton("Restore Selected")
        restore_btn.setObjectName("PrimaryButton")
        restore_btn.clicked.connect(self.restore_selected)
        btn_row.addStretch()
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(restore_btn)
        outer.addLayout(btn_row)

    def reload_backups(self):
        self.list_widget.clear()
        backups = self.backup.list_backups(kind="all")
        if not backups:
            self.list_widget.addItem("No backups found yet.")
            return
        for filename, full_path, kind in backups:
            item = QListWidgetItem(_friendly_label(filename, kind))
            item.setData(Qt.UserRole, full_path)
            self.list_widget.addItem(item)

    def restore_selected(self):
        item = self.list_widget.currentItem()
        if not item or not item.data(Qt.UserRole):
            QMessageBox.information(self, "No selection", "Select a backup from the list first.")
            return
        full_path = item.data(Qt.UserRole)
        incremental = full_path.endswith(".zip") and is_incremental_backup(full_path)

        if incremental:
            confirm = QMessageBox.question(
                self, "Confirm restore",
                "This will merge the records from this backup into what's "
                "already here. Matching records are updated only if newer; "
                "nothing existing is removed. Continue?"
            )
            if confirm != QMessageBox.Yes:
                return
            try:
                imported, updated, skipped_records, skipped_categories = restore_incremental_backup(
                    full_path, self.cc, self.rc
                )
                msg = f"Added {imported} new record(s), updated {updated}."
                if skipped_records:
                    msg += f" Skipped {skipped_records} (already up to date)."
                if skipped_categories:
                    msg += ("\n\nThese categories no longer exist and were skipped: "
                            + ", ".join(skipped_categories))
                QMessageBox.information(self, "Restore complete", msg)
                self.result_kind = "incremental"
                self.accept()
            except Exception as e:
                QMessageBox.critical(self, "Restore failed", str(e))
        else:
            confirm = QMessageBox.warning(
                self, "Confirm restore",
                "This will REPLACE your current data with this full backup.\n\n"
                "Your current data will be saved as a safety backup first, and "
                "your login username/password will NOT change. Continue?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No
            )
            if confirm != QMessageBox.Yes:
                return
            try:
                self.backup.restore_backup(full_path)
                self.result_kind = "full"
                self.accept()
            except Exception as e:
                QMessageBox.critical(self, "Restore failed", str(e))
