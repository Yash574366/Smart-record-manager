from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QHBoxLayout, QLabel, QCheckBox,
    QComboBox, QSpinBox, QPushButton, QFileDialog
)


class BackupSettingsDialog(QDialog):
    def __init__(self, session, org_settings, parent=None):
        super().__init__(parent)
        self.session = session
        self.org_settings = org_settings
        self.setWindowTitle("Backup Settings")
        self.resize(420, 320)

        outer = QVBoxLayout(self)
        form = QFormLayout()

        self.enabled_checkbox = QCheckBox("Enable automatic backups")
        self.enabled_checkbox.setChecked(bool(org_settings.backup_enabled))
        form.addRow(self.enabled_checkbox)

        folder_row = QHBoxLayout()
        self.folder_label = QLabel(org_settings.backup_folder or "Using default local folder")
        self.folder_label.setWordWrap(True)
        choose_btn = QPushButton("Choose Folder")
        choose_btn.clicked.connect(self.pick_folder)
        clear_btn = QPushButton("Use Default")
        clear_btn.clicked.connect(self.clear_folder)
        folder_row.addWidget(self.folder_label, stretch=1)
        folder_row.addWidget(choose_btn)
        folder_row.addWidget(clear_btn)
        form.addRow("Backup Folder", folder_row)

        self.frequency_combo = QComboBox()
        self.frequency_options = [
            ("Every 6 hours", 6), ("Every 12 hours", 12),
            ("Daily", 24), ("Weekly", 168),
        ]
        self.frequency_combo.addItems([label for label, _ in self.frequency_options])
        current_hours = org_settings.backup_frequency_hours or 24
        closest_idx = min(range(len(self.frequency_options)),
                           key=lambda i: abs(self.frequency_options[i][1] - current_hours))
        self.frequency_combo.setCurrentIndex(closest_idx)
        form.addRow("Automatic Backup Frequency", self.frequency_combo)

        self.compression_checkbox = QCheckBox("Compress backup files (recommended)")
        self.compression_checkbox.setChecked(bool(org_settings.backup_compression_enabled))
        form.addRow(self.compression_checkbox)

        self.retention_spin = QSpinBox()
        self.retention_spin.setRange(7, 1095)  # 1 week to 3 years
        self.retention_spin.setSuffix(" days")
        self.retention_spin.setValue(org_settings.backup_retention_days or 180)
        form.addRow("Auto-delete Automatic Backups after", self.retention_spin)

        note = QLabel("Manual backups (\"Backup All Records\") are never auto-deleted.")
        note.setStyleSheet("color: #64748B; font-size: 8pt;")
        note.setWordWrap(True)

        outer.addLayout(form)
        outer.addWidget(note)

        btn_row = QHBoxLayout()
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setObjectName("SecondaryButton")
        cancel_btn.clicked.connect(self.reject)
        save_btn = QPushButton("Save")
        save_btn.setObjectName("PrimaryButton")
        save_btn.clicked.connect(self.save)
        btn_row.addStretch()
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(save_btn)
        outer.addLayout(btn_row)

    def pick_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Choose a folder for backups")
        if folder:
            self.folder_label.setText(folder)

    def clear_folder(self):
        self.folder_label.setText("Using default local folder")

    def save(self):
        self.org_settings.backup_enabled = self.enabled_checkbox.isChecked()
        label_text = self.folder_label.text()
        self.org_settings.backup_folder = (
            None if label_text == "Using default local folder" else label_text
        )
        _, hours = self.frequency_options[self.frequency_combo.currentIndex()]
        self.org_settings.backup_frequency_hours = hours
        self.org_settings.backup_compression_enabled = self.compression_checkbox.isChecked()
        self.org_settings.backup_retention_days = self.retention_spin.value()
        self.session.commit()
        self.accept()
