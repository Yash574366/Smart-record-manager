from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QHBoxLayout, QLineEdit, QComboBox,
    QSpinBox, QPushButton, QLabel, QFileDialog, QMessageBox, QListWidget,
    QListWidgetItem, QInputDialog
)
from PySide6.QtCore import Qt

from app.models.models import UserRole


class SettingsDialog(QDialog):
    def __init__(self, session, org_settings, auth_controller, on_theme_change, parent=None):
        super().__init__(parent)
        self.session = session
        self.org_settings = org_settings
        self.auth = auth_controller
        self.on_theme_change = on_theme_change
        self.setWindowTitle("Settings")
        self.resize(480, 480)

        outer = QVBoxLayout(self)
        form = QFormLayout()

        self.org_name_input = QLineEdit(org_settings.organization_name)
        form.addRow("Organization Name", self.org_name_input)

        logo_row = QHBoxLayout()
        self.logo_label = QLabel(org_settings.logo_path or "No logo")
        logo_btn = QPushButton("Choose Logo")
        logo_btn.clicked.connect(self.pick_logo)
        logo_row.addWidget(self.logo_label, stretch=1)
        logo_row.addWidget(logo_btn)
        form.addRow("Logo", logo_row)

        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["light", "dark"])
        self.theme_combo.setCurrentText(org_settings.theme)
        form.addRow("Theme", self.theme_combo)

        self.color_input = QLineEdit(org_settings.theme_color)
        self.color_input.setPlaceholderText("#2563EB")
        form.addRow("Theme Color (hex)", self.color_input)

        self.font_size_input = QSpinBox()
        self.font_size_input.setRange(8, 16)
        self.font_size_input.setValue(org_settings.font_size)
        form.addRow("Font Size", self.font_size_input)

        self.language_combo = QComboBox()
        self.language_combo.addItems(["en", "hi", "es", "fr"])
        self.language_combo.setCurrentText(org_settings.language)
        form.addRow("Language", self.language_combo)

        outer.addLayout(form)

        note = QLabel("Backup folder, frequency, and retention are configured "
                       "in Menu → Backup → Backup Settings.")
        note.setStyleSheet("color: #64748B; font-size: 8pt;")
        note.setWordWrap(True)
        outer.addWidget(note)

        if self.auth.can_manage_fields():  # admin only
            outer.addWidget(QLabel("Users"))
            self.user_list = QListWidget()
            self.reload_users()
            outer.addWidget(self.user_list)
            user_btn_row = QHBoxLayout()
            add_user_btn = QPushButton("+ Add User")
            add_user_btn.clicked.connect(self.add_user)
            change_pw_btn = QPushButton("Change Password")
            change_pw_btn.clicked.connect(self.change_selected_password)
            rename_user_btn = QPushButton("Rename User")
            rename_user_btn.clicked.connect(self.rename_selected_user)
            delete_user_btn = QPushButton("Delete User")
            delete_user_btn.clicked.connect(self.delete_selected_user)
            user_btn_row.addWidget(add_user_btn)
            user_btn_row.addWidget(change_pw_btn)
            user_btn_row.addWidget(rename_user_btn)
            user_btn_row.addWidget(delete_user_btn)
            outer.addLayout(user_btn_row)

        btn_row = QHBoxLayout()
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setObjectName("SecondaryButton")
        cancel_btn.clicked.connect(self.reject)
        save_btn = QPushButton("Save")
        save_btn.setObjectName("PrimaryButton")
        save_btn.clicked.connect(self.save)
        btn_row.addStretch()
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(save_btn)
        outer.addLayout(btn_row)

    def pick_logo(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select Logo", filter="Images (*.png *.jpg *.jpeg)")
        if path:
            self.logo_label.setText(path)

    def reload_users(self):
        from app.models.models import User
        self.user_list.clear()
        for user in self.session.query(User).all():
            item = QListWidgetItem(f"{user.username}  ({user.role.value})")
            item.setData(Qt.UserRole, user.id)
            self.user_list.addItem(item)

    def add_user(self):
        username, ok = QInputDialog.getText(self, "New User", "Username:")
        if not (ok and username.strip()):
            return
        password, ok2 = QInputDialog.getText(self, "New User", "Password:")
        if not (ok2 and password):
            return
        role_str, ok3 = QInputDialog.getItem(
            self, "Role", "Role:", [r.value for r in UserRole], editable=False)
        if not ok3:
            return
        try:
            self.auth.create_user(username.strip(), password, UserRole(role_str))
            self.reload_users()
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def change_selected_password(self):
        from app.models.models import User
        item = self.user_list.currentItem()
        if not item or not item.data(Qt.UserRole):
            QMessageBox.information(self, "No selection", "Select a user from the list first.")
            return
        user_id = item.data(Qt.UserRole)
        user = self.session.query(User).get(user_id)
        if not user:
            return

        old_password, ok0 = QInputDialog.getText(
            self, "Change Password", f"Current password for '{user.username}':",
            QLineEdit.Password
        )
        if not ok0:
            return
        if not self.auth.verify_user_password(user, old_password):
            QMessageBox.critical(self, "Incorrect password",
                                  "That's not the current password. Password was not changed.")
            return

        new_password, ok = QInputDialog.getText(
            self, "Change Password", f"New password for '{user.username}':",
            QLineEdit.Password
        )
        if not (ok and new_password):
            return
        confirm_password, ok2 = QInputDialog.getText(
            self, "Change Password", "Confirm new password:", QLineEdit.Password
        )
        if not ok2:
            return
        if new_password != confirm_password:
            QMessageBox.warning(self, "Passwords don't match", "Please try again.")
            return

        self.auth.change_password(user, new_password)
        QMessageBox.information(self, "Password changed", f"Password updated for '{user.username}'.")

    def _current_selected_user(self):
        from app.models.models import User
        item = self.user_list.currentItem()
        if not item or not item.data(Qt.UserRole):
            return None
        return self.session.query(User).get(item.data(Qt.UserRole))

    def rename_selected_user(self):
        user = self._current_selected_user()
        if not user:
            QMessageBox.information(self, "No selection", "Select a user from the list first.")
            return
        new_username, ok = QInputDialog.getText(
            self, "Rename User", "New username:", text=user.username)
        if not (ok and new_username.strip()):
            return
        try:
            self.auth.rename_user(user, new_username.strip())
            self.reload_users()
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def delete_selected_user(self):
        user = self._current_selected_user()
        if not user:
            QMessageBox.information(self, "No selection", "Select a user from the list first.")
            return

        confirm = QMessageBox.warning(
            self, "Confirm delete",
            f"Delete user '{user.username}'? This cannot be undone.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if confirm != QMessageBox.Yes:
            return

        admin_password, ok = QInputDialog.getText(
            self, "Confirm your password",
            "Enter YOUR password to confirm this deletion:", QLineEdit.Password
        )
        if not ok:
            return

        success, message = self.auth.delete_user(user, admin_password)
        if success:
            QMessageBox.information(self, "User deleted", f"'{user.username}' has been removed.")
            self.reload_users()
        else:
            QMessageBox.critical(self, "Could not delete user", message)

    def save(self):
        self.org_settings.organization_name = self.org_name_input.text().strip() or "My Organization"
        self.org_settings.logo_path = self.logo_label.text() if self.logo_label.text() != "No logo" else None
        self.org_settings.theme = self.theme_combo.currentText()
        self.org_settings.theme_color = self.color_input.text().strip() or "#2563EB"
        self.org_settings.font_size = self.font_size_input.value()
        self.org_settings.language = self.language_combo.currentText()
        self.session.commit()
        self.on_theme_change()
        self.accept()
