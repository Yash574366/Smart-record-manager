from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem,
    QPushButton, QLabel, QLineEdit, QAbstractItemView
)
from PySide6.QtCore import Qt


class RecordPickerDialog(QDialog):
    """Shown when the person clicks Edit / Delete / Pin, so choosing a
    profile happens at that moment - not by pre-selecting a row by clicking
    on it in the table. Includes a search box to filter long lists."""

    def __init__(self, records, display_fields, title="Select a profile",
                 single_select=True, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(420, 480)
        self.selected_ids = []
        self.single_select = single_select

        outer = QVBoxLayout(self)
        outer.addWidget(QLabel(title))

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search...")
        self.search_input.textChanged.connect(self._apply_filter)
        outer.addWidget(self.search_input)

        # Pre-build (label, record_id) pairs once so filtering is instant
        self._all_entries = []
        for record in records:
            values = {fv.field_id: fv.value for fv in record.field_values}
            parts = [values.get(f.id) for f in display_fields if values.get(f.id)]
            label = "  •  ".join(parts) if parts else f"Record #{record.id}"
            if record.is_pinned:
                label = f"📌 {label}"
            self._all_entries.append((label, record.id))

        self.list_widget = QListWidget()
        self.list_widget.setSelectionMode(
            QAbstractItemView.SingleSelection if single_select else QAbstractItemView.ExtendedSelection
        )
        outer.addWidget(self.list_widget, stretch=1)
        self._populate(self._all_entries)

        btn_row = QHBoxLayout()
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setObjectName("SecondaryButton")
        cancel_btn.clicked.connect(self.reject)
        confirm_btn = QPushButton("Confirm")
        confirm_btn.setObjectName("PrimaryButton")
        confirm_btn.clicked.connect(self._confirm)
        btn_row.addStretch()
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(confirm_btn)
        outer.addLayout(btn_row)

    def _populate(self, entries):
        self.list_widget.clear()
        if not entries:
            self.list_widget.addItem("No matching records.")
            return
        for label, record_id in entries:
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, record_id)
            self.list_widget.addItem(item)

    def _apply_filter(self, text):
        text = text.strip().lower()
        if not text:
            self._populate(self._all_entries)
            return
        filtered = [(label, rid) for label, rid in self._all_entries if text in label.lower()]
        self._populate(filtered)

    def _confirm(self):
        self.selected_ids = [
            item.data(Qt.UserRole) for item in self.list_widget.selectedItems()
            if item.data(Qt.UserRole) is not None
        ]
        if self.selected_ids:
            self.accept()
        else:
            self.reject()
