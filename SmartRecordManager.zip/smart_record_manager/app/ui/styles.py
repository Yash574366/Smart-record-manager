"""Qt stylesheets for light/dark themes. accent_color is injected at runtime
from OrgSettings.theme_color so admins can rebrand the app.

Design language: quiet, structured, "professional office software" - flat
surfaces with a single crisp accent, generous spacing, subtle borders instead
of heavy shadows (Qt renders shadows poorly), rounded-but-not-bubbly corners
(8-12px), and a sidebar treated as a distinct navigation plane rather than
just another panel.
"""

LIGHT_BASE = """
QWidget {{ background-color: #F6F7FB; color: #1E2430; font-family: "Segoe UI", "Inter", sans-serif; font-size: {font_size}pt; }}
QMainWindow {{ background-color: #F6F7FB; }}

#Sidebar {{ background-color: #FFFFFF; border-right: 1px solid #E7E9F0; }}
#BrandLabel {{ font-size: 12.5pt; font-weight: 700; color: #14181F; letter-spacing: 0.2px; }}
#LogoFrame {{ background-color: #FFFFFF; border: 1px solid #E7E9F0; border-radius: 10px; }}

#SidebarButton {{
    background-color: transparent; border: none; text-align: left;
    padding: 10px 14px; border-radius: 8px; color: #47516A; font-weight: 500;
    font-size: {font_size}pt;
}}
#SidebarButton:hover {{ background-color: #F0F2F8; }}
#SidebarButton:checked {{
    background-color: {accent}1A; color: {accent}; font-weight: 700;
    border-left: 3px solid {accent};
    padding-left: 11px;
}}

#TopBar {{ background-color: #FFFFFF; border-bottom: 1px solid #E7E9F0; }}
#UserLabel {{ color: #47516A; font-weight: 600; }}
#MenuButton {{
    border: 1px solid #E7E9F0; border-radius: 8px; padding: 6px 14px;
    background-color: #FFFFFF; font-weight: 600; color: #1E2430;
}}
#MenuButton:hover {{ background-color: #F0F2F8; }}
#MenuButton::menu-indicator {{ image: none; }}

QPushButton#PrimaryButton {{
    background-color: {accent}; color: white; border-radius: 8px;
    padding: 9px 20px; font-weight: 700; border: none;
}}
QPushButton#PrimaryButton:hover {{ background-color: {accent}E6; }}
QPushButton#PrimaryButton:pressed {{ background-color: {accent}CC; }}

QPushButton#SecondaryButton {{
    background-color: #FFFFFF; color: #2B3244; border: 1px solid #E0E3EC;
    border-radius: 8px; padding: 9px 18px; font-weight: 600;
}}
QPushButton#SecondaryButton:hover {{ background-color: #F0F2F8; border-color: {accent}55; }}
QPushButton#SecondaryButton:pressed {{ background-color: #E7E9F0; }}

QPushButton {{
    border-radius: 8px; padding: 7px 14px;
}}

#Card {{ background-color: #FFFFFF; border-radius: 12px; border: 1px solid #E7E9F0; }}

QLineEdit, QComboBox, QDateEdit, QSpinBox, QTextEdit {{
    background-color: #FFFFFF; border: 1.5px solid #E0E3EC; border-radius: 8px;
    padding: 7px 11px; selection-background-color: {accent}33;
}}
QLineEdit:focus, QComboBox:focus, QDateEdit:focus, QTextEdit:focus {{ border: 1.5px solid {accent}; }}
QComboBox::drop-down {{ border: none; width: 24px; }}

QTableWidget {{
    background-color: #FFFFFF; border: 1px solid #E7E9F0; border-radius: 10px;
    gridline-color: #F0F2F8; alternate-background-color: #FAFBFD;
}}
QHeaderView::section {{
    background-color: #FAFBFD; padding: 10px 8px; border: none;
    border-bottom: 2px solid #E7E9F0; font-weight: 700; color: #47516A;
}}
QTableWidget::item {{ padding: 4px 6px; border-bottom: 1px solid #F3F4F8; }}
QTableWidget::item:selected {{ background-color: {accent}1F; color: #14181F; }}

QScrollBar:vertical {{ background: transparent; width: 10px; margin: 0; }}
QScrollBar::handle:vertical {{ background: #D6D9E3; border-radius: 5px; min-height: 24px; }}
QScrollBar::handle:vertical:hover {{ background: #C1C5D3; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}

QMenu {{ background-color: #FFFFFF; border: 1px solid #E7E9F0; border-radius: 8px; padding: 6px; }}
QMenu::item {{ padding: 8px 16px; border-radius: 6px; }}
QMenu::item:selected {{ background-color: {accent}1A; color: {accent}; }}
QMenu::separator {{ height: 1px; background: #E7E9F0; margin: 6px 4px; }}

QListWidget {{
    background-color: #FFFFFF; border: 1px solid #E7E9F0; border-radius: 8px;
}}
QListWidget::item {{ padding: 8px; border-bottom: 1px solid #F3F4F8; }}
QListWidget::item:selected {{ background-color: {accent}1A; color: {accent}; }}
"""

DARK_BASE = """
QWidget {{ background-color: #12151C; color: #E6E9F0; font-family: "Segoe UI", "Inter", sans-serif; font-size: {font_size}pt; }}
QMainWindow {{ background-color: #12151C; }}

#Sidebar {{ background-color: #171B24; border-right: 1px solid #262B37; }}
#BrandLabel {{ font-size: 12.5pt; font-weight: 700; color: #F5F6FA; letter-spacing: 0.2px; }}
#LogoFrame {{ background-color: #1E2330; border: 1px solid #2C3242; border-radius: 10px; }}

#SidebarButton {{
    background-color: transparent; border: none; text-align: left;
    padding: 10px 14px; border-radius: 8px; color: #AEB4C4; font-weight: 500;
    font-size: {font_size}pt;
}}
#SidebarButton:hover {{ background-color: #1E2330; }}
#SidebarButton:checked {{
    background-color: {accent}26; color: {accent}; font-weight: 700;
    border-left: 3px solid {accent};
    padding-left: 11px;
}}

#TopBar {{ background-color: #171B24; border-bottom: 1px solid #262B37; }}
#UserLabel {{ color: #AEB4C4; font-weight: 600; }}
#MenuButton {{
    border: 1px solid #2C3242; border-radius: 8px; padding: 6px 14px;
    background-color: #1E2330; font-weight: 600; color: #E6E9F0;
}}
#MenuButton:hover {{ background-color: #262B37; }}
#MenuButton::menu-indicator {{ image: none; }}

QPushButton#PrimaryButton {{
    background-color: {accent}; color: white; border-radius: 8px;
    padding: 9px 20px; font-weight: 700; border: none;
}}
QPushButton#PrimaryButton:hover {{ background-color: {accent}E6; }}
QPushButton#PrimaryButton:pressed {{ background-color: {accent}CC; }}

QPushButton#SecondaryButton {{
    background-color: #1E2330; color: #E6E9F0; border: 1px solid #2C3242;
    border-radius: 8px; padding: 9px 18px; font-weight: 600;
}}
QPushButton#SecondaryButton:hover {{ background-color: #262B37; border-color: {accent}66; }}
QPushButton#SecondaryButton:pressed {{ background-color: #12151C; }}

QPushButton {{
    border-radius: 8px; padding: 7px 14px;
}}

#Card {{ background-color: #171B24; border-radius: 12px; border: 1px solid #262B37; }}

QLineEdit, QComboBox, QDateEdit, QSpinBox, QTextEdit {{
    background-color: #1E2330; border: 1.5px solid #2C3242; border-radius: 8px;
    padding: 7px 11px; color: #E6E9F0; selection-background-color: {accent}44;
}}
QLineEdit:focus, QComboBox:focus, QDateEdit:focus, QTextEdit:focus {{ border: 1.5px solid {accent}; }}
QComboBox::drop-down {{ border: none; width: 24px; }}

QTableWidget {{
    background-color: #171B24; border: 1px solid #262B37; border-radius: 10px;
    gridline-color: #232838; color: #E6E9F0; alternate-background-color: #1B202B;
}}
QHeaderView::section {{
    background-color: #1B202B; padding: 10px 8px; border: none;
    border-bottom: 2px solid #2C3242; font-weight: 700; color: #AEB4C4;
}}
QTableWidget::item {{ padding: 4px 6px; border-bottom: 1px solid #1E2330; }}
QTableWidget::item:selected {{ background-color: {accent}33; color: #F5F6FA; }}

QScrollBar:vertical {{ background: transparent; width: 10px; margin: 0; }}
QScrollBar::handle:vertical {{ background: #2C3242; border-radius: 5px; min-height: 24px; }}
QScrollBar::handle:vertical:hover {{ background: #3A4154; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}

QMenu {{ background-color: #1E2330; border: 1px solid #2C3242; border-radius: 8px; padding: 6px; }}
QMenu::item {{ padding: 8px 16px; border-radius: 6px; color: #E6E9F0; }}
QMenu::item:selected {{ background-color: {accent}33; color: {accent}; }}
QMenu::separator {{ height: 1px; background: #2C3242; margin: 6px 4px; }}

QListWidget {{
    background-color: #171B24; border: 1px solid #262B37; border-radius: 8px;
}}
QListWidget::item {{ padding: 8px; border-bottom: 1px solid #1E2330; }}
QListWidget::item:selected {{ background-color: {accent}33; color: {accent}; }}
"""


def build_stylesheet(theme: str, accent_color: str, font_size: int = 10) -> str:
    template = DARK_BASE if theme == "dark" else LIGHT_BASE
    return template.format(accent=accent_color, font_size=font_size)
