import os
from datetime import datetime

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QMessageBox
)
from PySide6.QtMultimedia import QCamera, QMediaCaptureSession, QImageCapture, QMediaDevices
from PySide6.QtMultimediaWidgets import QVideoWidget


class CameraCaptureDialog(QDialog):
    """Live camera preview with a Capture button - saves the photo as a JPEG
    into save_dir and reports its path back via self.captured_path."""

    def __init__(self, save_dir: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Take Photo")
        self.resize(520, 460)
        self.captured_path = None
        self.save_dir = save_dir
        os.makedirs(save_dir, exist_ok=True)

        self.camera = None
        self.capture_session = None
        self.image_capture = None

        layout = QVBoxLayout(self)

        available_cameras = QMediaDevices.videoInputs()
        if not available_cameras:
            layout.addWidget(QLabel("No camera was detected on this system."))
            btn_row = QHBoxLayout()
            close_btn = QPushButton("Close")
            close_btn.setObjectName("SecondaryButton")
            close_btn.clicked.connect(self.reject)
            btn_row.addStretch()
            btn_row.addWidget(close_btn)
            layout.addLayout(btn_row)
            return

        self.video_widget = QVideoWidget()
        layout.addWidget(self.video_widget, stretch=1)

        hint = QLabel("Position yourself in frame, then click Capture.")
        hint.setStyleSheet("color: #64748B;")
        layout.addWidget(hint)

        btn_row = QHBoxLayout()
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setObjectName("SecondaryButton")
        cancel_btn.clicked.connect(self.reject)
        capture_btn = QPushButton("📷 Capture")
        capture_btn.setObjectName("PrimaryButton")
        capture_btn.clicked.connect(self.capture)
        btn_row.addStretch()
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(capture_btn)
        layout.addLayout(btn_row)

        try:
            self.camera = QCamera(available_cameras[0])
            self.capture_session = QMediaCaptureSession()
            self.capture_session.setCamera(self.camera)
            self.capture_session.setVideoOutput(self.video_widget)
            self.image_capture = QImageCapture()
            self.capture_session.setImageCapture(self.image_capture)
            self.image_capture.imageSaved.connect(self._on_image_saved)
            self.image_capture.errorOccurred.connect(self._on_error)
            self.camera.start()
        except Exception as e:
            QMessageBox.critical(self, "Camera error", f"Could not start the camera: {e}")
            self.reject()

    def capture(self):
        if not self.image_capture:
            return
        filename = f"camera_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
        path = os.path.join(self.save_dir, filename)
        self.image_capture.captureToFile(path)

    def _on_image_saved(self, request_id, path):
        self.captured_path = path
        if self.camera:
            self.camera.stop()
        self.accept()

    def _on_error(self, request_id, error, error_string):
        QMessageBox.critical(self, "Capture failed", error_string)

    def closeEvent(self, event):
        if self.camera:
            self.camera.stop()
        super().closeEvent(event)
