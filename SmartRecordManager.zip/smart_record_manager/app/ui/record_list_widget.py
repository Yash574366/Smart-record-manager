from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QTableWidget,
    QTableWidgetItem, QLabel, QMessageBox, QHeaderView, QAbstractItemView
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

from app.ui.record_form_dialog import RecordFormDialog
from app.ui.record_picker_dialog import RecordPickerDialog
from app.utils.photo_store import load_pixmap_for_record

TABLE_FONT_SIZE = 13   # point size for table cell text and headers
PHOTO_COLUMN_WIDTH = 64
ROW_HEIGHT = 60
PHOTO_THUMB_SIZE = 44


class RecordListWidget(QWidget):
    def __init__(self, category, record_controller, auth_controller, on_change=None):
        super().__init__()
        self.category = category
        self.rc = record_controller
        self.auth = auth_controller
        self.on_change = on_change  # callback to refresh dashboard etc.
        self.current_page = 1
        self.page_size = 50

        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 24, 24, 24)
        outer.setSpacing(14)

        header_row = QHBoxLayout()
        title = QLabel(category.name)
        title.setStyleSheet("font-size: 18pt; font-weight: 700;")
        header_row.addWidget(title)
        header_row.addStretch()

        if self.auth.can_edit():
            add_btn = QPushButton(f"+ Add {category.name[:-1] if category.name.endswith('s') else category.name}")
            add_btn.setObjectName("PrimaryButton")
            add_btn.clicked.connect(self.add_record)
            header_row.addWidget(add_btn)
        outer.addLayout(header_row)

        toolbar = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText(f"Search {category.name.lower()}... (name, ID, phone, any field)")
        self.search_input.textChanged.connect(self.refresh)
        toolbar.addWidget(self.search_input, stretch=1)

        if self.auth.can_edit():
            pin_btn = QPushButton("📌 Pin / Unpin")
            pin_btn.setObjectName("SecondaryButton")
            pin_btn.clicked.connect(self.pin_flow)
            toolbar.addWidget(pin_btn)
        outer.addLayout(toolbar)

        self.table = QTableWidget()
        # No click-to-select: choosing a profile only happens through the
        # Edit / Delete / Pin buttons, which each ask you to pick at that moment.
        self.table.setSelectionMode(QAbstractItemView.NoSelection)
        self.table.setFocusPolicy(Qt.NoFocus)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        # Interactive (not Stretch) - Stretch was squeezing columns to fit the
        # window width, which is what cut off headers like "Roll Number" ->
        # "Roll Numbe". Interactive keeps every column at its full natural
        # width and lets the table scroll horizontally instead of shrinking text.
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.table.horizontalHeader().setStretchLastSection(False)
        self.table.horizontalHeader().setMinimumSectionSize(90)
        self.table.horizontalScrollBar().setEnabled(True)
        self.table.setSortingEnabled(True)
        self.table.verticalHeader().setDefaultSectionSize(ROW_HEIGHT)

        # Bigger font for both cell text and header labels
        big_font = QFont()
        big_font.setPointSize(TABLE_FONT_SIZE)
        self.table.setFont(big_font)
        header_font = QFont()
        header_font.setPointSize(TABLE_FONT_SIZE)
        header_font.setBold(True)
        self.table.horizontalHeader().setFont(header_font)
        self.table.horizontalHeader().setMinimumHeight(40)

        outer.addWidget(self.table, stretch=1)

        action_row = QHBoxLayout()
        self.edit_btn = QPushButton("Edit")
        self.edit_btn.setObjectName("SecondaryButton")
        self.edit_btn.clicked.connect(self.edit_flow)
        self.delete_btn = QPushButton("Delete")
        self.delete_btn.setObjectName("SecondaryButton")
        self.delete_btn.clicked.connect(self.delete_flow)
        action_row.addWidget(self.edit_btn)
        action_row.addWidget(self.delete_btn)
        action_row.addStretch()
        outer.addLayout(action_row)

        self.visible_fields = sorted(
            [f for f in category.fields if f.show_in_table],
            key=lambda f: f.sort_order
        )
        self.refresh()

    # ------------------------------------------------------------------
    def current_records(self):
        """The records currently shown (respects the active search filter) -
        used both to populate the table and the Edit/Delete/Pin pickers, so
        picking stays consistent with what's on screen."""
        query = self.search_input.text().strip()
        if query:
            records, _ = self.rc.search(self.category.id, query, page=1, page_size=500)
        else:
            records = self.rc.list_records(self.category.id, page=1, page_size=500)
        return records

    def refresh(self):
        records = self.current_records()
        show_photo = self.category.has_photo

        headers = (["Photo"] if show_photo else []) + [f.name for f in self.visible_fields] + ["Updated"]
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setRowCount(len(records))
        if show_photo:
            self.table.setColumnWidth(0, PHOTO_COLUMN_WIDTH)

        field_start_col = 1 if show_photo else 0

        for row_idx, record in enumerate(records):
            values = {fv.field_id: fv.value for fv in record.field_values}

            if show_photo:
                # Photo thumbnail, first column, left side
                photo_label = QLabel()
                photo_label.setAlignment(Qt.AlignCenter)
                pixmap = load_pixmap_for_record(record, PHOTO_THUMB_SIZE)
                if pixmap.isNull():
                    pin_marker = "📌 " if record.is_pinned else ""
                    photo_label.setText(f"{pin_marker}👤")
                    photo_label.setStyleSheet("font-size: 18pt; color: #94A3B8;")
                else:
                    photo_label.setPixmap(pixmap)
                self.table.setCellWidget(row_idx, 0, photo_label)

            for offset, field in enumerate(self.visible_fields):
                col_idx = field_start_col + offset
                value_text = values.get(field.id, "") or ""
                if offset == 0 and record.is_pinned:
                    value_text = f"📌 {value_text}"
                item = QTableWidgetItem(value_text)
                self.table.setItem(row_idx, col_idx, item)

            updated_item = QTableWidgetItem(record.updated_at.strftime("%b %d, %Y %I:%M %p"))
            self.table.setItem(row_idx, len(headers) - 1, updated_item)

        self.table.resizeColumnsToContents()
        for col in range(self.table.columnCount()):
            if show_photo and col == 0:
                continue
            self.table.setColumnWidth(col, self.table.columnWidth(col) + 24)
        if show_photo:
            self.table.setColumnWidth(0, PHOTO_COLUMN_WIDTH)

    def _get_record_by_id(self, record_id):
        return next((r for r in self.rc.list_records(self.category.id, page=1, page_size=100000)
                     if r.id == record_id), None)

    # ------------------------------------------------------------------
    def add_record(self):
        dialog = RecordFormDialog(self.category, self.rc, parent=self)
        if dialog.exec():
            self.refresh()
            if self.on_change:
                self.on_change()

    def edit_flow(self):
        records = self.current_records()
        if not records:
            QMessageBox.information(self, "Nothing to edit", "There are no records yet.")
            return
        picker = RecordPickerDialog(records, self.visible_fields,
                                     title="Select the profile to edit",
                                     single_select=True, parent=self)
        if not picker.exec():
            return
        record = self._get_record_by_id(picker.selected_ids[0])
        if not record:
            return
        dialog = RecordFormDialog(self.category, self.rc, existing_record=record, parent=self)
        if dialog.exec():
            self.refresh()
            if self.on_change:
                self.on_change()

    def pin_flow(self):
        records = self.current_records()
        if not records:
            QMessageBox.information(self, "Nothing to pin", "There are no records yet.")
            return
        picker = RecordPickerDialog(records, self.visible_fields,
                                     title="Select profile(s) to pin/unpin",
                                     single_select=False, parent=self)
        if not picker.exec():
            return
        for rid in picker.selected_ids:
            record = self._get_record_by_id(rid)
            if record:
                self.rc.toggle_pin(record)
        self.refresh()

    def delete_flow(self):
        records = self.current_records()
        if not records:
            QMessageBox.information(self, "Nothing to delete", "There are no records yet.")
            return
        picker = RecordPickerDialog(records, self.visible_fields,
                                     title="Select profile(s) to delete",
                                     single_select=False, parent=self)
        if not picker.exec():
            return

        confirm = QMessageBox.question(
            self, "Confirm delete",
            f"Move {len(picker.selected_ids)} record(s) to Recycle Bin?"
        )
        if confirm == QMessageBox.Yes:
            for rid in picker.selected_ids:
                record = self._get_record_by_id(rid)
                if record:
                    self.rc.soft_delete(record)
            self.refresh()
            if self.on_change:
                self.on_change()
