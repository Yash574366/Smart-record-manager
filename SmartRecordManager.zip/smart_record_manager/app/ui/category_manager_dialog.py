from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem, QPushButton,
    QLineEdit, QLabel, QComboBox, QCheckBox, QMessageBox, QInputDialog, QSplitter, QWidget
)
from PySide6.QtCore import Qt

from app.models.models import FieldType


class CategoryManagerDialog(QDialog):
    """Lets an admin create/rename/delete categories and add/rename/delete/
    reorder the unlimited custom fields within each category."""

    def __init__(self, category_controller, parent=None):
        super().__init__(parent)
        self.cc = category_controller
        self.setWindowTitle("Manage Categories & Fields")
        self.resize(720, 480)

        outer = QVBoxLayout(self)
        splitter = QSplitter()
        outer.addWidget(splitter, stretch=1)

        # Left: category list
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.addWidget(QLabel("Categories"))
        self.category_list = QListWidget()
        self.category_list.currentItemChanged.connect(self.load_fields)
        left_layout.addWidget(self.category_list)

        cat_btn_row = QHBoxLayout()
        add_cat_btn = QPushButton("+ New")
        add_cat_btn.clicked.connect(self.add_category)
        rename_cat_btn = QPushButton("Rename")
        rename_cat_btn.clicked.connect(self.rename_category)
        delete_cat_btn = QPushButton("Delete")
        delete_cat_btn.clicked.connect(self.delete_category)
        cat_btn_row.addWidget(add_cat_btn)
        cat_btn_row.addWidget(rename_cat_btn)
        cat_btn_row.addWidget(delete_cat_btn)
        left_layout.addLayout(cat_btn_row)

        self.photo_checkbox = QCheckBox("Use a photo for this category")
        self.photo_checkbox.stateChanged.connect(self.toggle_photo_enabled)
        left_layout.addWidget(self.photo_checkbox)

        splitter.addWidget(left)

        # Right: field list for selected category
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.addWidget(QLabel("Custom Fields"))
        self.field_list = QListWidget()
        right_layout.addWidget(self.field_list)

        field_btn_row = QHBoxLayout()
        add_field_btn = QPushButton("+ Add Field")
        add_field_btn.clicked.connect(self.add_field)
        rename_field_btn = QPushButton("Rename")
        rename_field_btn.clicked.connect(self.rename_field)
        type_field_btn = QPushButton("Change Type")
        type_field_btn.clicked.connect(self.change_field_type)
        delete_field_btn = QPushButton("Delete")
        delete_field_btn.clicked.connect(self.delete_field)
        field_btn_row.addWidget(add_field_btn)
        field_btn_row.addWidget(rename_field_btn)
        field_btn_row.addWidget(type_field_btn)
        field_btn_row.addWidget(delete_field_btn)
        right_layout.addLayout(field_btn_row)
        splitter.addWidget(right)

        close_btn = QPushButton("Close")
        close_btn.setObjectName("PrimaryButton")
        close_btn.clicked.connect(self.accept)
        outer.addWidget(close_btn)

        self.reload_categories()

    # ------------------------------------------------------------------
    def reload_categories(self):
        self.category_list.clear()
        for cat in self.cc.list_categories():
            item = QListWidgetItem(cat.name)
            item.setData(Qt.UserRole, cat.id)
            self.category_list.addItem(item)
        if self.category_list.count():
            self.category_list.setCurrentRow(0)

    def current_category(self):
        item = self.category_list.currentItem()
        if not item:
            return None
        cat_id = item.data(Qt.UserRole)
        return next((c for c in self.cc.list_categories() if c.id == cat_id), None)

    def load_fields(self):
        self.field_list.clear()
        cat = self.current_category()

        self.photo_checkbox.blockSignals(True)
        self.photo_checkbox.setChecked(bool(cat.has_photo) if cat else False)
        self.photo_checkbox.setEnabled(cat is not None)
        self.photo_checkbox.blockSignals(False)

        if not cat:
            return
        for field in sorted(cat.fields, key=lambda f: f.sort_order):
            label = f"{field.name}  [{field.field_type.value}]" + (" *required" if field.is_required else "")
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, field.id)
            self.field_list.addItem(item)

    def toggle_photo_enabled(self, state):
        cat = self.current_category()
        if cat:
            self.cc.set_has_photo(cat, self.photo_checkbox.isChecked())

    # ---- Category actions -------------------------------------------------
    def add_category(self):
        name, ok = QInputDialog.getText(self, "New Category", "Category name:")
        if ok and name.strip():
            self.cc.create_category(name.strip())
            self.reload_categories()

    def rename_category(self):
        cat = self.current_category()
        if not cat:
            return
        name, ok = QInputDialog.getText(self, "Rename Category", "New name:", text=cat.name)
        if ok and name.strip():
            self.cc.rename_category(cat, name.strip())
            self.reload_categories()

    def delete_category(self):
        cat = self.current_category()
        if not cat:
            return
        confirm = QMessageBox.question(
            self, "Confirm delete",
            f"Delete category '{cat.name}' and ALL its records? This cannot be undone."
        )
        if confirm == QMessageBox.Yes:
            self.cc.delete_category(cat)
            self.reload_categories()

    # ---- Field actions -----------------------------------------------------
    def add_field(self):
        cat = self.current_category()
        if not cat:
            QMessageBox.information(self, "No category", "Select or create a category first.")
            return
        name, ok = QInputDialog.getText(self, "New Field", "Field name:")
        if not (ok and name.strip()):
            return
        type_names = [t.value for t in FieldType]
        type_str, ok2 = QInputDialog.getItem(self, "Field Type", "Type:", type_names, editable=False)
        if not ok2:
            return
        field_type = FieldType(type_str)
        dropdown_options = None
        if field_type == FieldType.DROPDOWN:
            opts, ok3 = QInputDialog.getText(self, "Dropdown Options", "Comma-separated options:")
            if ok3:
                dropdown_options = opts
        required = QMessageBox.question(self, "Required?", "Should this field be required?") == QMessageBox.Yes
        self.cc.add_field(cat, name.strip(), field_type, is_required=required,
                           dropdown_options=dropdown_options)
        self.load_fields()

    def rename_field(self):
        field = self._current_field()
        if not field:
            return
        name, ok = QInputDialog.getText(self, "Rename Field", "New name:", text=field.name)
        if ok and name.strip():
            self.cc.rename_field(field, name.strip())
            self.load_fields()

    def change_field_type(self):
        field = self._current_field()
        if not field:
            return
        type_names = [t.value for t in FieldType]
        type_str, ok = QInputDialog.getItem(
            self, "Change Field Type", "New type:", type_names,
            current=type_names.index(field.field_type.value), editable=False
        )
        if ok:
            self.cc.change_field_type(field, FieldType(type_str))
            self.load_fields()

    def delete_field(self):
        field = self._current_field()
        if not field:
            return
        confirm = QMessageBox.question(self, "Confirm delete", f"Delete field '{field.name}'? All its data will be lost.")
        if confirm == QMessageBox.Yes:
            self.cc.delete_field(field)
            self.load_fields()

    def _current_field(self):
        item = self.field_list.currentItem()
        cat = self.current_category()
        if not item or not cat:
            return None
        field_id = item.data(Qt.UserRole)
        return next((f for f in cat.fields if f.id == field_id), None)
