from datetime import datetime, timedelta

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QPushButton, QLabel, QMessageBox, QHeaderView, QAbstractItemView
)
from PySide6.QtCore import Qt

RETENTION_DAYS = 10


class RecycleBinDialog(QDialog):
    """Shows every soft-deleted record across all categories. Records are
    permanently purged automatically after RETENTION_DAYS days (checked each
    time this dialog opens, and once at app startup)."""

    def __init__(self, record_controller, parent=None):
        super().__init__(parent)
        self.rc = record_controller
        self.setWindowTitle("Recycle Bin")
        self.resize(760, 460)

        outer = QVBoxLayout(self)

        title = QLabel("🗑  Recycle Bin")
        title.setStyleSheet("font-size: 15pt; font-weight: 700;")
        outer.addWidget(title)

        info = QLabel(f"Deleted records are kept for {RETENTION_DAYS} days, then removed automatically.")
        info.setStyleSheet("color: #64748B;")
        outer.addWidget(info)

        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["Category", "Record", "Deleted On", "Days Left", ""])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        outer.addWidget(self.table, stretch=1)

        btn_row = QHBoxLayout()
        restore_btn = QPushButton("Restore Selected")
        restore_btn.setObjectName("PrimaryButton")
        restore_btn.clicked.connect(self.restore_selected)
        delete_btn = QPushButton("Delete Permanently")
        delete_btn.setObjectName("SecondaryButton")
        delete_btn.clicked.connect(self.delete_permanently)
        close_btn = QPushButton("Close")
        close_btn.setObjectName("SecondaryButton")
        close_btn.clicked.connect(self.accept)
        btn_row.addWidget(restore_btn)
        btn_row.addWidget(delete_btn)
        btn_row.addStretch()
        btn_row.addWidget(close_btn)
        outer.addLayout(btn_row)

        self.reload()

    def reload(self):
        # Purge anything past its retention window before displaying
        self.rc.empty_recycle_bin(older_than_days=RETENTION_DAYS)

        records = self.rc.list_all_deleted()
        self.table.setRowCount(len(records))
        for row_idx, record in enumerate(records):
            name_value = next((fv.value for fv in record.field_values if fv.value), f"Record #{record.id}")
            deleted_on = record.deleted_at.strftime("%b %d, %Y %I:%M %p") if record.deleted_at else "-"
            days_left = RETENTION_DAYS
            if record.deleted_at:
                elapsed = (datetime.now() - record.deleted_at).days
                days_left = max(0, RETENTION_DAYS - elapsed)

            cat_item = QTableWidgetItem(record.category.name)
            cat_item.setData(Qt.UserRole, record.id)
            name_item = QTableWidgetItem(name_value)
            deleted_item = QTableWidgetItem(deleted_on)
            days_item = QTableWidgetItem(f"{days_left} day(s)")

            self.table.setItem(row_idx, 0, cat_item)
            self.table.setItem(row_idx, 1, name_item)
            self.table.setItem(row_idx, 2, deleted_item)
            self.table.setItem(row_idx, 3, days_item)
            self.table.setItem(row_idx, 4, QTableWidgetItem(""))

        if not records:
            self.table.setRowCount(1)
            empty_item = QTableWidgetItem("Recycle Bin is empty.")
            self.table.setItem(0, 0, empty_item)
            self.table.setSpan(0, 0, 1, 5)

    def _selected_record_ids(self):
        rows = {idx.row() for idx in self.table.selectionModel().selectedRows()}
        ids = []
        for row in rows:
            item = self.table.item(row, 0)
            if item and item.data(Qt.UserRole):
                ids.append(item.data(Qt.UserRole))
        return ids

    def restore_selected(self):
        ids = self._selected_record_ids()
        if not ids:
            QMessageBox.information(self, "No selection", "Select a record to restore.")
            return
        for record in self.rc.list_all_deleted():
            if record.id in ids:
                self.rc.restore(record)
        self.reload()
        QMessageBox.information(self, "Restored", "Record(s) restored to their original category.")

    def delete_permanently(self):
        ids = self._selected_record_ids()
        if not ids:
            QMessageBox.information(self, "No selection", "Select one or more records to delete.")
            return
        confirm = QMessageBox.warning(
            self, "Confirm permanent delete",
            "Are you sure you want to permanently delete the selected records? "
            "This action cannot be undone.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if confirm == QMessageBox.Yes:
            matched = [r for r in self.rc.list_all_deleted() if r.id in ids]
            self.rc.permanently_delete_many(matched)
            self.reload()
