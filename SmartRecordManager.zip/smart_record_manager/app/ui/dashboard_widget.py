from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QGridLayout, QFrame, QScrollArea
)
from PySide6.QtCore import Qt


class StatCard(QFrame):
    def __init__(self, title: str, value: str, accent="#2563EB"):
        super().__init__()
        self.setObjectName("Card")
        self.setMinimumHeight(100)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)

        value_label = QLabel(value)
        value_label.setStyleSheet(f"font-size: 26pt; font-weight: 700; color: {accent};")
        title_label = QLabel(title)
        title_label.setStyleSheet("color: #64748B; font-size: 10pt;")

        layout.addWidget(value_label)
        layout.addWidget(title_label)


class DashboardWidget(QWidget):
    def __init__(self, record_controller, accent_color="#2563EB"):
        super().__init__()
        self.rc = record_controller
        self.accent_color = accent_color

        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 24, 24, 24)
        outer.setSpacing(20)

        header = QLabel("Dashboard")
        header.setStyleSheet("font-size: 20pt; font-weight: 700;")
        outer.addWidget(header)

        self.stats_row = QHBoxLayout()
        outer.addLayout(self.stats_row)

        recent_label = QLabel("Recently Added Records")
        recent_label.setStyleSheet("font-size: 13pt; font-weight: 600; margin-top: 10px;")
        outer.addWidget(recent_label)

        self.recent_frame = QFrame()
        self.recent_frame.setObjectName("Card")
        self.recent_layout = QVBoxLayout(self.recent_frame)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self.recent_frame)
        outer.addWidget(scroll, stretch=1)

        self.refresh()

    def refresh(self):
        stats = self.rc.dashboard_stats()

        # Clear + rebuild stat cards
        while self.stats_row.count():
            item = self.stats_row.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        self.stats_row.addWidget(StatCard("Total Records", str(stats["total_records"]), self.accent_color))
        self.stats_row.addWidget(StatCard("Total Categories", str(stats["total_categories"]), self.accent_color))
        top_cat = max(stats["per_category"].items(), key=lambda kv: kv[1], default=("-", 0))
        self.stats_row.addWidget(StatCard("Largest Category", f"{top_cat[0]} ({top_cat[1]})", self.accent_color))

        # Clear + rebuild recent list
        while self.recent_layout.count():
            item = self.recent_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        if not stats["recent_records"]:
            self.recent_layout.addWidget(QLabel("No records yet."))
        for r in stats["recent_records"]:
            name_field = next((fv.value for fv in r.field_values), "Record")
            row = QLabel(f"#{r.id}  •  {r.category.name}  •  {name_field}  •  {r.created_at.strftime('%b %d, %Y %I:%M %p')}")
            row.setStyleSheet("padding: 6px 0; border-bottom: 1px solid #F1F5F9;")
            self.recent_layout.addWidget(row)
        self.recent_layout.addStretch()
