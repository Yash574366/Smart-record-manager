from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox
)
from PySide6.QtCore import Qt


class LoginDialog(QDialog):
    def __init__(self, auth_controller, org_name="Smart Record Manager", parent=None):
        super().__init__(parent)
        self.auth_controller = auth_controller
        self.setWindowTitle("Sign in")
        self.setFixedSize(360, 320)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 32, 32, 32)
        layout.setSpacing(14)

        title = QLabel(org_name)
        title.setStyleSheet("font-size: 18pt; font-weight: 700;")
        title.setAlignment(Qt.AlignCenter)
        subtitle = QLabel("Sign in to continue")
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setStyleSheet("color: #64748B;")

        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("Username")
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Password")
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.returnPressed.connect(self.attempt_login)

        login_btn = QPushButton("Sign In")
        login_btn.setObjectName("PrimaryButton")
        login_btn.clicked.connect(self.attempt_login)

        credit_label = QLabel("Product by Yash Kumar")
        credit_label.setAlignment(Qt.AlignCenter)
        credit_label.setStyleSheet("color: #94A3B8; font-size: 8pt;")

        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addSpacing(10)
        layout.addWidget(self.username_input)
        layout.addWidget(self.password_input)
        layout.addWidget(login_btn)
        layout.addStretch()
        layout.addWidget(credit_label)

    def attempt_login(self):
        username = self.username_input.text().strip()
        password = self.password_input.text()
        if not username or not password:
            QMessageBox.warning(self, "Missing info", "Enter both username and password.")
            return

        ok, message = self.auth_controller.login(username, password)
        if ok:
            self.accept()
        else:
            QMessageBox.critical(self, "Login failed", message)
            self.password_input.clear()
