"""First-run database seeding: default admin user + example categories/fields."""
from sqlalchemy import inspect, text

from app.models.models import (
    init_db, OrgSettings, User, UserRole, Category, FieldDef, FieldType
)
from app.utils.security import hash_password
from app.utils.credentials_store import upsert_credential


DEFAULT_ADMIN_USERNAME = "admin"
DEFAULT_ADMIN_PASSWORD = "admin123"   # user is prompted to change this on first login


def _run_lightweight_migrations(engine):
    """Adds any new columns that don't exist yet on an existing database file,
    so updating the app's code doesn't break customers who already have data.
    (SQLAlchemy's create_all only creates missing TABLES, not missing COLUMNS
    on tables that already exist - this covers that gap.)"""
    inspector = inspect(engine)
    with engine.begin() as conn:
        if "org_settings" in inspector.get_table_names():
            org_columns = {col["name"] for col in inspector.get_columns("org_settings")}
            if "backup_folder" not in org_columns:
                conn.execute(text("ALTER TABLE org_settings ADD COLUMN backup_folder VARCHAR(500)"))
            if "last_incremental_backup_at" not in org_columns:
                conn.execute(text("ALTER TABLE org_settings ADD COLUMN last_incremental_backup_at DATETIME"))
            if "backup_enabled" not in org_columns:
                conn.execute(text("ALTER TABLE org_settings ADD COLUMN backup_enabled BOOLEAN DEFAULT 1"))
            if "backup_frequency_hours" not in org_columns:
                conn.execute(text("ALTER TABLE org_settings ADD COLUMN backup_frequency_hours INTEGER DEFAULT 24"))
            if "backup_retention_days" not in org_columns:
                conn.execute(text("ALTER TABLE org_settings ADD COLUMN backup_retention_days INTEGER DEFAULT 180"))
            if "backup_compression_enabled" not in org_columns:
                conn.execute(text("ALTER TABLE org_settings ADD COLUMN backup_compression_enabled BOOLEAN DEFAULT 1"))
        if "records" in inspector.get_table_names():
            record_columns = {col["name"] for col in inspector.get_columns("records")}
            if "photo_data" not in record_columns:
                conn.execute(text("ALTER TABLE records ADD COLUMN photo_data BLOB"))
        if "categories" in inspector.get_table_names():
            category_columns = {col["name"] for col in inspector.get_columns("categories")}
            if "has_photo" not in category_columns:
                # Default existing categories to 1 (photo enabled) so nothing
                # that already had photos suddenly loses them.
                conn.execute(text("ALTER TABLE categories ADD COLUMN has_photo BOOLEAN DEFAULT 1"))


def bootstrap_database(db_path: str, credentials_file: str = None):
    engine, Session = init_db(db_path)
    _run_lightweight_migrations(engine)
    session = Session()

    try:
        # Org settings (single row)
        if session.query(OrgSettings).count() == 0:
            session.add(OrgSettings(id=1))

        # Default admin
        if session.query(User).count() == 0:
            pw_hash, salt = hash_password(DEFAULT_ADMIN_PASSWORD)
            session.add(User(
                username=DEFAULT_ADMIN_USERNAME,
                password_hash=pw_hash,
                salt=salt,
                role=UserRole.ADMIN,
                full_name="Administrator",
            ))
            upsert_credential(credentials_file, DEFAULT_ADMIN_USERNAME, DEFAULT_ADMIN_PASSWORD)

        # Example category: Students (only seeded if DB is brand new)
        if session.query(Category).count() == 0:
            students = Category(name="Students", icon="graduation-cap",
                                 description="Student records")
            session.add(students)
            session.flush()  # get students.id

            default_fields = [
                ("Name", FieldType.TEXT, True, 0),
                ("Roll Number", FieldType.TEXT, True, 1),
                ("Class", FieldType.TEXT, False, 2),
                ("Section", FieldType.TEXT, False, 3),
                ("Age", FieldType.NUMBER, False, 4),
                ("Phone", FieldType.PHONE, False, 5),
                ("Email", FieldType.EMAIL, False, 6),
                ("Address", FieldType.LONG_TEXT, False, 7),
                ("Guardian Name", FieldType.TEXT, False, 8),
                ("Blood Group", FieldType.DROPDOWN, False, 9),
                ("Date of Joining", FieldType.DATE, False, 10),
                ("Fees", FieldType.NUMBER, False, 11),
            ]
            for name, ftype, required, order in default_fields:
                fd = FieldDef(
                    category_id=students.id, name=name, field_type=ftype,
                    is_required=required, sort_order=order,
                )
                if ftype == FieldType.DROPDOWN and name == "Blood Group":
                    fd.dropdown_options = "A+,A-,B+,B-,O+,O-,AB+,AB-"
                session.add(fd)

            # A second example category to show it's not school-only
            employees = Category(name="Employees", icon="briefcase",
                                  description="Staff / employee records")
            session.add(employees)
            session.flush()
            emp_fields = [
                ("Name", FieldType.TEXT, True, 0),
                ("Employee ID", FieldType.TEXT, True, 1),
                ("Department", FieldType.TEXT, False, 2),
                ("Phone", FieldType.PHONE, False, 3),
                ("Email", FieldType.EMAIL, False, 4),
                ("Salary", FieldType.NUMBER, False, 5),
                ("Date of Joining", FieldType.DATE, False, 6),
            ]
            for name, ftype, required, order in emp_fields:
                session.add(FieldDef(
                    category_id=employees.id, name=name, field_type=ftype,
                    is_required=required, sort_order=order,
                ))

        session.commit()
    finally:
        session.close()

    return engine, Session
