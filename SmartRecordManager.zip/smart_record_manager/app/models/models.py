"""
Smart Record Manager - Database Models
========================================
Normalized SQLAlchemy schema supporting UNLIMITED custom fields per category.

Design idea (EAV-lite pattern):
  Category      -> defines a "type" of record (Students, Employees, Patients, ...)
  FieldDef      -> defines a custom field belonging to a Category (Name, Roll No, ...)
  Record        -> one actual record (a student, an employee, a book, ...)
  FieldValue    -> the value of one FieldDef for one Record

This lets the admin add/rename/delete fields at runtime without ever touching
the database schema or migrating tables - which is what "unlimited custom fields"
requires in practice.
"""
from datetime import datetime
from enum import Enum as PyEnum

from sqlalchemy import (
    create_engine, Column, Integer, String, Text, Boolean, DateTime,
    ForeignKey, ForeignKeyConstraint, UniqueConstraint, Enum, LargeBinary
)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

Base = declarative_base()


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------
class FieldType(PyEnum):
    TEXT = "text"
    NUMBER = "number"
    DATE = "date"
    EMAIL = "email"
    PHONE = "phone"
    DROPDOWN = "dropdown"
    CHECKBOX = "checkbox"
    IMAGE = "image"
    FILE = "file"
    LONG_TEXT = "long_text"


class UserRole(PyEnum):
    ADMIN = "admin"
    STAFF = "staff"
    VIEWER = "viewer"


# ---------------------------------------------------------------------------
# Organization-level settings (single-row table)
# ---------------------------------------------------------------------------
class OrgSettings(Base):
    __tablename__ = "org_settings"

    id = Column(Integer, primary_key=True, default=1)
    organization_name = Column(String(255), default="My Organization")
    logo_path = Column(String(500), nullable=True)
    theme = Column(String(20), default="light")       # light / dark
    theme_color = Column(String(20), default="#2563EB")
    language = Column(String(10), default="en")
    font_size = Column(Integer, default=10)
    backup_folder = Column(String(500), nullable=True)  # e.g. a Google Drive/OneDrive synced folder
    last_incremental_backup_at = Column(DateTime, nullable=True)  # checkpoint for incremental auto-backups
    backup_enabled = Column(Boolean, default=True)
    backup_frequency_hours = Column(Integer, default=24)
    backup_retention_days = Column(Integer, default=180)
    backup_compression_enabled = Column(Boolean, default=True)


# ---------------------------------------------------------------------------
# Users / Auth
# ---------------------------------------------------------------------------
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    username = Column(String(100), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    salt = Column(String(64), nullable=False)
    role = Column(Enum(UserRole), default=UserRole.STAFF, nullable=False)
    full_name = Column(String(255), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.now)
    last_login = Column(DateTime, nullable=True)


# ---------------------------------------------------------------------------
# Categories (Students, Employees, Patients, Books, ...)
# ---------------------------------------------------------------------------
class Category(Base):
    __tablename__ = "categories"

    id = Column(Integer, primary_key=True)
    name = Column(String(150), unique=True, nullable=False)
    icon = Column(String(50), default="folder")
    description = Column(Text, nullable=True)
    has_photo = Column(Boolean, default=True)  # whether records in this category use a photo at all
    created_at = Column(DateTime, default=datetime.now)

    fields = relationship("FieldDef", back_populates="category",
                           cascade="all, delete-orphan", order_by="FieldDef.sort_order")
    records = relationship("Record", back_populates="category",
                            cascade="all, delete-orphan")


# ---------------------------------------------------------------------------
# Dynamic Field Definitions
# ---------------------------------------------------------------------------
class FieldDef(Base):
    __tablename__ = "field_defs"
    __table_args__ = (UniqueConstraint("category_id", "name", name="uq_field_per_category"),)

    id = Column(Integer, primary_key=True)
    category_id = Column(Integer, ForeignKey("categories.id"), nullable=False)
    name = Column(String(150), nullable=False)
    field_type = Column(Enum(FieldType), default=FieldType.TEXT, nullable=False)
    is_required = Column(Boolean, default=False)
    is_unique = Column(Boolean, default=False)
    dropdown_options = Column(Text, nullable=True)   # comma-separated for DROPDOWN
    sort_order = Column(Integer, default=0)
    show_in_table = Column(Boolean, default=True)    # column visible in list view

    category = relationship("Category", back_populates="fields")
    values = relationship("FieldValue", back_populates="field", cascade="all, delete-orphan")


# ---------------------------------------------------------------------------
# Records (an actual student / employee / patient / book entry)
# ---------------------------------------------------------------------------
class Record(Base):
    __tablename__ = "records"

    id = Column(Integer, primary_key=True)
    category_id = Column(Integer, ForeignKey("categories.id"), nullable=False)
    photo_path = Column(String(500), nullable=True)
    photo_data = Column(LargeBinary, nullable=True)  # durable copy - survives the photo file being auto-cleaned after 30 days
    notes = Column(Text, nullable=True)
    is_favorite = Column(Boolean, default=False)
    is_pinned = Column(Boolean, default=False)
    is_deleted = Column(Boolean, default=False)      # recycle bin (soft delete)
    deleted_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    qr_code_path = Column(String(500), nullable=True)

    category = relationship("Category", back_populates="records")
    field_values = relationship("FieldValue", back_populates="record",
                                 cascade="all, delete-orphan")
    attachments = relationship("Attachment", back_populates="record",
                                cascade="all, delete-orphan")
    history = relationship("RecordHistory", back_populates="record",
                            cascade="all, delete-orphan", order_by="RecordHistory.changed_at.desc()")


class FieldValue(Base):
    __tablename__ = "field_values"
    __table_args__ = (UniqueConstraint("record_id", "field_id", name="uq_value_per_field"),)

    id = Column(Integer, primary_key=True)
    record_id = Column(Integer, ForeignKey("records.id"), nullable=False)
    field_id = Column(Integer, ForeignKey("field_defs.id"), nullable=False)
    value = Column(Text, nullable=True)   # stored as text; cast by field_type in the UI layer

    record = relationship("Record", back_populates="field_values")
    field = relationship("FieldDef", back_populates="values")


# ---------------------------------------------------------------------------
# Attachments (documents / files attached to a record)
# ---------------------------------------------------------------------------
class Attachment(Base):
    __tablename__ = "attachments"

    id = Column(Integer, primary_key=True)
    record_id = Column(Integer, ForeignKey("records.id"), nullable=False)
    file_name = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=False)
    uploaded_at = Column(DateTime, default=datetime.now)

    record = relationship("Record", back_populates="attachments")


# ---------------------------------------------------------------------------
# Record History (edit trail)
# ---------------------------------------------------------------------------
class RecordHistory(Base):
    __tablename__ = "record_history"

    id = Column(Integer, primary_key=True)
    record_id = Column(Integer, ForeignKey("records.id"), nullable=False)
    changed_by = Column(String(100), nullable=True)
    change_summary = Column(Text, nullable=False)
    changed_at = Column(DateTime, default=datetime.now)

    record = relationship("Record", back_populates="history")


# ---------------------------------------------------------------------------
# Global Activity Log (login, delete, bulk-edit, backup events, ...)
# ---------------------------------------------------------------------------
class ActivityLog(Base):
    __tablename__ = "activity_log"

    id = Column(Integer, primary_key=True)
    username = Column(String(100), nullable=True)
    action = Column(String(255), nullable=False)
    details = Column(Text, nullable=True)
    timestamp = Column(DateTime, default=datetime.now)


# ---------------------------------------------------------------------------
# Reminders (birthdays, fee due dates, custom reminders)
# ---------------------------------------------------------------------------
class Reminder(Base):
    __tablename__ = "reminders"

    id = Column(Integer, primary_key=True)
    record_id = Column(Integer, ForeignKey("records.id"), nullable=True)
    title = Column(String(255), nullable=False)
    due_date = Column(DateTime, nullable=False)
    is_recurring_yearly = Column(Boolean, default=False)   # for birthdays
    is_done = Column(Boolean, default=False)


# ---------------------------------------------------------------------------
# Engine / Session factory
# ---------------------------------------------------------------------------
def get_engine(db_path: str):
    """SQLite by default. Swap the connection string here to migrate to
    MySQL/PostgreSQL later, e.g.:
      mysql+pymysql://user:pass@host/dbname
      postgresql+psycopg2://user:pass@host/dbname
    Because the ORM layer (this file) is database-agnostic, no model code
    needs to change - only this connection string."""
    return create_engine(f"sqlite:///{db_path}", echo=False, future=True)


def init_db(db_path: str):
    engine = get_engine(db_path)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, future=True)
    return engine, Session
