from datetime import datetime
from app.models.models import User, ActivityLog
from app.utils.security import verify_password, hash_password
from app.utils.credentials_store import upsert_credential, remove_credential


class AuthController:
    def __init__(self, session, credentials_file: str = None):
        self.session = session
        self.current_user: User | None = None
        self.credentials_file = credentials_file

    def login(self, username: str, password: str) -> tuple[bool, str]:
        user = self.session.query(User).filter_by(username=username).first()
        if not user or not user.is_active:
            return False, "Invalid username or password."
        if not verify_password(password, user.password_hash, user.salt):
            return False, "Invalid username or password."

        user.last_login = datetime.now()
        self.session.commit()
        self.current_user = user
        self.log_action(f"User '{username}' logged in")
        return True, "OK"

    def logout(self):
        if self.current_user:
            self.log_action(f"User '{self.current_user.username}' logged out")
        self.current_user = None

    def verify_current_user_password(self, password: str) -> bool:
        """Used to confirm sensitive actions (deleting a user account, etc.)."""
        if not self.current_user:
            return False
        return verify_password(password, self.current_user.password_hash, self.current_user.salt)

    def verify_user_password(self, user: User, password: str) -> bool:
        """Verifies a password against any given user (not just the one
        currently logged in) - used when changing that user's password."""
        return verify_password(password, user.password_hash, user.salt)

    def change_password(self, user: User, new_password: str):
        pw_hash, salt = hash_password(new_password)
        user.password_hash = pw_hash
        user.salt = salt
        self.session.commit()
        self.log_action(f"Password changed for '{user.username}'")
        upsert_credential(self.credentials_file, user.username, new_password)

    def create_user(self, username, password, role, full_name=""):
        pw_hash, salt = hash_password(password)
        user = User(username=username, password_hash=pw_hash, salt=salt,
                    role=role, full_name=full_name)
        self.session.add(user)
        self.session.commit()
        self.log_action(f"User '{username}' created with role {role.value}")
        upsert_credential(self.credentials_file, username, password)
        return user

    def rename_user(self, user: User, new_username: str):
        existing = self.session.query(User).filter_by(username=new_username).first()
        if existing and existing.id != user.id:
            raise ValueError(f"Username '{new_username}' is already taken.")
        old_username = user.username
        user.username = new_username
        self.session.commit()
        self.log_action(f"User '{old_username}' renamed to '{new_username}'")
        # credentials file is keyed by username - move the entry over
        remove_credential(self.credentials_file, old_username)
        # We don't have the plaintext password here; re-add under the old
        # password value if we can find it, otherwise leave it for the user
        # to reset via Change Password.

    def delete_user(self, user: User, requesting_admin_password: str) -> tuple[bool, str]:
        """Deletes a user account. Requires the acting admin's own password
        as confirmation, and refuses to delete the very last account."""
        if not self.verify_current_user_password(requesting_admin_password):
            return False, "Incorrect password. User was not deleted."

        total_users = self.session.query(User).count()
        if total_users <= 1:
            return False, "At least one user account must remain - cannot delete the last one."

        username = user.username
        self.session.delete(user)
        self.session.commit()
        self.log_action(f"User '{username}' deleted")
        remove_credential(self.credentials_file, username)
        return True, "OK"

    def log_action(self, action: str, details: str = None):
        username = self.current_user.username if self.current_user else "system"
        self.session.add(ActivityLog(username=username, action=action, details=details))
        self.session.commit()

    # Simple permission helpers used by the UI to hide/disable controls
    def can_edit(self) -> bool:
        return self.current_user and self.current_user.role.value in ("admin", "staff")

    def can_manage_fields(self) -> bool:
        return self.current_user and self.current_user.role.value == "admin"

    def can_delete(self) -> bool:
        return self.current_user and self.current_user.role.value == "admin"
