"""
Backup / restore for the SQLite database file.

Key guarantees this module enforces:
  - Backups NEVER contain login credentials (username/password/role). The
    `users` table is stripped out of every backup at creation time, and
    restoring ANY backup re-applies whatever login credentials were active
    right before the restore - so login never changes because of a restore,
    no matter how old the backup is.
  - Manual and Automatic backups are kept in separate folders and are never
    mixed, and never deleted by the same rule (auto-delete only ever
    touches Auto/, and never removes the single newest automatic backup).

For MySQL/PostgreSQL deployments, replace the sqlite3-specific pieces here
with mysqldump / pg_dump equivalents.
"""
import json
import os
import shutil
import sqlite3
import uuid
import zipfile
from datetime import datetime

BACKUP_FORMAT_VERSION = 2


class BackupController:
    def __init__(self, db_path: str, default_backup_dir: str, org_settings=None):
        """org_settings, if provided, is checked on every call for a
        `backup_folder` override (e.g. a Google Drive / OneDrive synced
        folder the admin picked in Settings) - so backups can land somewhere
        that survives this computer being lost or damaged."""
        self.db_path = db_path
        self.default_backup_dir = default_backup_dir
        self.org_settings = org_settings
        os.makedirs(default_backup_dir, exist_ok=True)

    # ------------------------------------------------------------------
    @property
    def backup_root(self) -> str:
        custom = getattr(self.org_settings, "backup_folder", None) if self.org_settings else None
        if custom:
            try:
                os.makedirs(custom, exist_ok=True)
                return custom
            except OSError:
                pass  # folder path invalid/unreachable (e.g. drive unplugged) - fall back
        return self.default_backup_dir

    @property
    def manual_dir(self) -> str:
        d = os.path.join(self.backup_root, "Manual")
        os.makedirs(d, exist_ok=True)
        return d

    @property
    def auto_dir(self) -> str:
        d = os.path.join(self.backup_root, "Auto")
        os.makedirs(d, exist_ok=True)
        return d

    # Backwards-compat: some older code/dialogs reference `backup_dir`
    @property
    def backup_dir(self) -> str:
        return self.backup_root

    # ------------------------------------------------------------------
    def _compression_level(self) -> int:
        enabled = getattr(self.org_settings, "backup_compression_enabled", True) if self.org_settings else True
        return zipfile.ZIP_DEFLATED if enabled else zipfile.ZIP_STORED

    def _strip_users_table(self, sqlite_path: str):
        """Removes every row from the users table in a COPY of the database
        so the resulting file contains zero login credentials."""
        conn = sqlite3.connect(sqlite_path)
        try:
            conn.execute("DELETE FROM users")
            conn.commit()
        finally:
            conn.close()

    def _read_users_table(self) -> list[dict]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute("SELECT * FROM users").fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def _write_users_table(self, rows: list[dict]):
        """Replaces the users table in self.db_path with exactly these rows -
        used right after a restore to put back whatever login credentials
        were active immediately before the restore happened."""
        if not rows:
            return
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("DELETE FROM users")
            columns = list(rows[0].keys())
            col_list = ", ".join(columns)
            placeholders = ", ".join("?" for _ in columns)
            conn.executemany(
                f"INSERT INTO users ({col_list}) VALUES ({placeholders})",
                [tuple(row[c] for c in columns) for row in rows],
            )
            conn.commit()
        finally:
            conn.close()

    def _write_metadata(self, zf: zipfile.ZipFile, backup_type: str, extra: dict = None):
        metadata = {
            "backup_id": uuid.uuid4().hex,
            "backup_version": BACKUP_FORMAT_VERSION,
            "backup_type": backup_type,   # "full" or "incremental"
            "backup_date": datetime.now().isoformat(),
        }
        if extra:
            metadata.update(extra)
        zf.writestr("backup_metadata.json", json.dumps(metadata, indent=2))
        return metadata

    # ------------------------------------------------------------------
    def create_full_backup(self, label: str = "manual") -> str:
        """A COMPLETE copy of every record, old and new - Employees,
        Students, Categories, Organization Info, Application Settings - but
        NEVER login credentials (the users table is stripped before
        zipping). This is the "Backup All Records" menu option, meant for
        e.g. archiving everything before permanently retiring a computer."""
        timestamp = datetime.now().strftime("%Y-%m-%d_%I-%M%p")
        filename = f"FullBackup_{timestamp}.zip"
        dest = os.path.join(self.manual_dir, filename)

        tmp_path = self.db_path + ".backup_tmp"
        try:
            shutil.copy2(self.db_path, tmp_path)
            self._strip_users_table(tmp_path)
            with zipfile.ZipFile(dest, "w", self._compression_level(), compresslevel=9) as zf:
                zf.write(tmp_path, arcname="records.db")
                self._write_metadata(zf, backup_type="full", extra={"label": label})
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        return dest

    # Kept for any code that still expects the old name
    def create_backup(self, label: str = "manual") -> str:
        return self.create_full_backup(label=label)

    # ------------------------------------------------------------------
    def list_backups(self, kind: str = "all"):
        """Returns (filename, full_path, kind) tuples, newest first.
        kind: "all", "manual", or "auto"."""
        results = []
        if kind in ("all", "manual") and os.path.isdir(self.manual_dir):
            for f in os.listdir(self.manual_dir):
                if f.endswith(".zip") or f.endswith(".db"):
                    results.append((f, os.path.join(self.manual_dir, f), "manual"))
        if kind in ("all", "auto") and os.path.isdir(self.auto_dir):
            for f in os.listdir(self.auto_dir):
                if f.endswith(".zip") or f.endswith(".db"):
                    results.append((f, os.path.join(self.auto_dir, f), "auto"))

        # Backward compatibility: pick up any backups made before the
        # Manual/Auto split existed, sitting directly in the backup root.
        if kind == "all" and os.path.isdir(self.backup_root):
            for f in os.listdir(self.backup_root):
                full = os.path.join(self.backup_root, f)
                if os.path.isfile(full) and (f.endswith(".zip") or f.endswith(".db")):
                    results.append((f, full, "manual" if "backup_all" in f or "FullBackup" in f else "auto"))

        results.sort(key=lambda r: os.path.getmtime(r[1]), reverse=True)
        return results

    # ------------------------------------------------------------------
    def restore_backup(self, backup_path: str):
        """Full restore - replaces the ENTIRE database with the backup's
        contents, EXCEPT login credentials, which are always preserved
        exactly as they were right before this restore ran."""
        if not os.path.exists(backup_path):
            raise FileNotFoundError(f"Backup not found: {backup_path}")

        current_users = self._read_users_table()
        self.create_full_backup(label="pre_restore_safety")  # safety copy before overwriting

        if backup_path.endswith(".zip"):
            with zipfile.ZipFile(backup_path, "r") as zf:
                names = zf.namelist()
                db_name = next((n for n in names if n.endswith(".db")), None)
                if not db_name:
                    raise ValueError("This backup file doesn't contain a database - can't restore it.")
                with zf.open(db_name) as src, open(self.db_path, "wb") as dst:
                    shutil.copyfileobj(src, dst)
        else:
            shutil.copy2(backup_path, self.db_path)  # older, pre-zip backup file

        # Login credentials are NEVER taken from a backup - always restore
        # whatever was active immediately before this restore.
        self._write_users_table(current_users)

    # ------------------------------------------------------------------
    def purge_old_auto_backups(self, older_than_days: int = 180) -> int:
        """Deletes AUTOMATIC backups older than N days (default: 6 months).
        Manual backups are never touched by this, and the single newest
        automatic backup is always kept regardless of its age, so there's
        never a moment with zero automatic backups."""
        auto_backups = self.list_backups(kind="auto")
        if len(auto_backups) <= 1:
            return 0  # nothing to delete, or only the newest exists

        newest_path = auto_backups[0][1]
        cutoff = datetime.now().timestamp() - (older_than_days * 86400)
        deleted = 0
        for filename, full_path, _kind in auto_backups[1:]:
            try:
                if os.path.getmtime(full_path) < cutoff:
                    os.remove(full_path)
                    deleted += 1
            except OSError:
                pass
        return deleted

    # Kept for compatibility with any older call sites
    def purge_old_backups(self, older_than_days: int = 180) -> int:
        return self.purge_old_auto_backups(older_than_days=older_than_days)
