"""Import / export records to CSV, Excel (.xlsx), JSON, and PDF."""
import csv
import json
import os
from datetime import datetime

from app.models.models import Category, FieldDef, Record, FieldValue


class IOController:
    def __init__(self, session, record_controller, category_controller):
        self.session = session
        self.rc = record_controller
        self.cc = category_controller

    def _category_rows(self, category: Category, include_deleted=False):
        fields = sorted(category.fields, key=lambda f: f.sort_order)
        headers = [f.name for f in fields] + ["Created At"]
        records = self.rc.list_records(category.id, include_deleted=include_deleted,
                                        page=1, page_size=1_000_000)
        rows = []
        for r in records:
            values = {fv.field_id: fv.value for fv in r.field_values}
            row = [values.get(f.id, "") for f in fields]
            row += [r.created_at.strftime("%Y-%m-%d %I:%M %p")]
            rows.append(row)
        return headers, rows, fields, records

    def _photo_bytes_for_record(self, record):
        """Prefers the on-disk file (in case it was updated since the last
        DB save); falls back to the durable database copy if the file has
        since been auto-cleaned."""
        if record.photo_path and os.path.exists(record.photo_path):
            try:
                with open(record.photo_path, "rb") as f:
                    return f.read()
            except OSError:
                pass
        if record.photo_data:
            return record.photo_data
        return None

    # ---- Export -------------------------------------------------------------
    def export_csv(self, category: Category, out_path: str):
        headers, rows, _fields, _records = self._category_rows(category)
        with open(out_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            writer.writerows(rows)
        return out_path

    def export_json(self, category: Category, out_path: str):
        headers, rows, _fields, _records = self._category_rows(category)
        data = [dict(zip(headers, row)) for row in rows]
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)
        return out_path

    def export_excel(self, category: Category, out_path: str):
        """Requires openpyxl + Pillow (see requirements.txt). Embeds each
        record's photo directly in the sheet, sized to fit its cell cleanly -
        only for categories that have the photo option enabled."""
        from openpyxl import Workbook
        from openpyxl.drawing.image import Image as XLImage
        from openpyxl.utils import get_column_letter
        import io

        headers, rows, fields, records = self._category_rows(category)
        wb = Workbook()
        ws = wb.active
        ws.title = category.name[:31]

        show_photo = category.has_photo
        full_headers = (["Photo"] if show_photo else []) + headers
        ws.append(full_headers)
        for cell in ws[1]:
            cell.font = cell.font.copy(bold=True)

        # Photo cell sized in real pixels, with the column/row set from the
        # same numbers (Excel column width is roughly (pixels-5)/7 "characters",
        # row height is pixels*0.75 points) so the image fits the cell exactly
        # instead of overflowing or leaving a big empty margin.
        CELL_PIXELS = 64
        IMAGE_PIXELS = 58  # slightly smaller than the cell so it doesn't get clipped
        data_start_col = 2 if show_photo else 1

        if show_photo:
            ws.column_dimensions[get_column_letter(1)].width = round((CELL_PIXELS - 5) / 7, 1)
        for offset, header in enumerate(headers):
            width = max(12, min(40, len(str(header)) + 4))
            ws.column_dimensions[get_column_letter(data_start_col + offset)].width = width

        for row_idx, (row, record) in enumerate(zip(rows, records), start=2):
            for offset, value in enumerate(row):
                ws.cell(row=row_idx, column=data_start_col + offset, value=value)
            if show_photo:
                ws.row_dimensions[row_idx].height = round(CELL_PIXELS * 0.75, 1)

                photo_bytes = self._photo_bytes_for_record(record)
                if photo_bytes:
                    try:
                        img = XLImage(io.BytesIO(photo_bytes))
                        img.width = IMAGE_PIXELS
                        img.height = IMAGE_PIXELS
                        ws.add_image(img, f"{get_column_letter(1)}{row_idx}")
                    except Exception:
                        pass  # unreadable/corrupted image data - skip that photo, keep the row

        wb.save(out_path)
        return out_path

    def export_pdf(self, category: Category, out_path: str):
        """Requires reportlab + Pillow (see requirements.txt). Embeds each
        record's photo directly in the table - only for categories that have
        the photo option enabled."""
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import landscape, A4
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Image as RLImage
        from reportlab.lib.styles import getSampleStyleSheet
        import io

        headers, rows, fields, records = self._category_rows(category)
        styles = getSampleStyleSheet()
        doc = SimpleDocTemplate(out_path, pagesize=landscape(A4))
        elements = [Paragraph(f"{category.name} - Records", styles["Title"])]

        show_photo = category.has_photo
        full_headers = (["Photo"] if show_photo else []) + headers
        table_data = [full_headers]
        for row, record in zip(rows, records):
            if show_photo:
                photo_bytes = self._photo_bytes_for_record(record)
                cell = ""
                if photo_bytes:
                    try:
                        cell = RLImage(io.BytesIO(photo_bytes), width=32, height=32)
                    except Exception:
                        cell = ""  # unreadable/corrupted image data - leave that cell blank
                table_data.append([cell] + row)
            else:
                table_data.append(row)

        table = Table(table_data, repeatRows=1)
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2563EB")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F3F4F6")]),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]))
        elements.append(table)
        doc.build(elements)
        return out_path
