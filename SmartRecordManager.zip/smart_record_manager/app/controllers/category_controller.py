from app.models.models import Category, FieldDef, FieldType


class CategoryController:
    def __init__(self, session):
        self.session = session

    # ---- Categories -----------------------------------------------------
    def list_categories(self):
        return self.session.query(Category).order_by(Category.name).all()

    def create_category(self, name: str, icon="folder", description=""):
        cat = Category(name=name, icon=icon, description=description)
        self.session.add(cat)
        self.session.commit()
        return cat

    def rename_category(self, category: Category, new_name: str):
        category.name = new_name
        self.session.commit()

    def delete_category(self, category: Category):
        self.session.delete(category)  # cascades to fields + records
        self.session.commit()

    def set_has_photo(self, category: Category, enabled: bool):
        category.has_photo = enabled
        self.session.commit()

    # ---- Dynamic Fields ---------------------------------------------------
    def add_field(self, category: Category, name: str, field_type: FieldType,
                  is_required=False, is_unique=False, dropdown_options=None,
                  show_in_table=True):
        sort_order = len(category.fields)
        field = FieldDef(
            category_id=category.id, name=name, field_type=field_type,
            is_required=is_required, is_unique=is_unique,
            dropdown_options=dropdown_options, sort_order=sort_order,
            show_in_table=show_in_table,
        )
        self.session.add(field)
        self.session.commit()
        return field

    def rename_field(self, field: FieldDef, new_name: str):
        field.name = new_name
        self.session.commit()

    def change_field_type(self, field: FieldDef, new_type: FieldType):
        field.field_type = new_type
        self.session.commit()

    def delete_field(self, field: FieldDef):
        self.session.delete(field)  # cascades to field_values
        self.session.commit()

    def reorder_fields(self, category: Category, ordered_field_ids: list[int]):
        for idx, fid in enumerate(ordered_field_ids):
            field = next(f for f in category.fields if f.id == fid)
            field.sort_order = idx
        self.session.commit()
