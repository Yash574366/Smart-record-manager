"""
Incremental (Automatic) backups.

Unlike BackupController.create_full_backup() (a complete copy of
everything - the "Backup All Records" menu option), an incremental backup
only contains records CREATED OR UPDATED SINCE THE LAST incremental
backup. This keeps routine automatic backups small and roughly
constant-sized over years of use, instead of growing to match the full
(ever-increasing) database every single time.

Storage format: a .zip in the Auto/ folder containing a JSON file listing,
per category, just the new/changed records (their field values by NAME,
their created_at/updated_at, plus their photo as base64) since the
checkpoint. It intentionally does NOT include a raw records.db copy, and
NEVER includes the users table - restoring one MERGES those records into
whatever database already exists (matched by a unique identifier field
where the category has one), it never replaces the whole database.
"""
import base64
import json
import os
import uuid
import zipfile
from datetime import datetime

from app.models.models import OrgSettings

BACKUP_FORMAT_VERSION = 2


def _identifier_field(category):
    """Picks the field used to recognize 'the same record' across backups -
    prefers a field explicitly marked unique, otherwise falls back to a
    field whose name looks like an ID (Employee ID, Roll Number, etc)."""
    for f in category.fields:
        if f.is_unique:
            return f
    for f in category.fields:
        name = f.name.lower()
        if "id" in name or "roll number" in name or "number" in name:
            return f
    return None


def create_incremental_backup(session, category_controller, record_controller,
                                backup_controller, label="auto"):
    """Returns (zip_path_or_None, record_count). Returns (None, 0) if there
    was nothing new/changed to back up - the checkpoint still advances so
    the next backup doesn't re-scan from further back than necessary."""
    org_settings = session.query(OrgSettings).first()
    checkpoint = org_settings.last_incremental_backup_at
    now = datetime.now()

    categories_payload = []
    total_new = 0

    for category in category_controller.list_categories():
        records = record_controller.list_records(category.id, page=1, page_size=1_000_000)
        # A record counts as "changed since checkpoint" if it was created OR
        # updated after the checkpoint. No checkpoint yet = first backup
        # ever, captures whatever already exists so nothing is skipped.
        changed_records = [
            r for r in records
            if checkpoint is None or r.created_at > checkpoint or r.updated_at > checkpoint
        ]
        if not changed_records:
            continue

        field_defs = sorted(category.fields, key=lambda f: f.sort_order)
        id_field = _identifier_field(category)
        category_entry = {
            "category_name": category.name,
            "identifier_field": id_field.name if id_field else None,
            "records": [],
        }
        for record in changed_records:
            values_by_field_id = {fv.field_id: fv.value for fv in record.field_values}
            field_values_by_name = {f.name: values_by_field_id.get(f.id, "") for f in field_defs}
            photo_b64 = base64.b64encode(record.photo_data).decode("ascii") if record.photo_data else None
            category_entry["records"].append({
                "created_at": record.created_at.isoformat(),
                "updated_at": record.updated_at.isoformat(),
                "field_values": field_values_by_name,
                "photo_base64": photo_b64,
            })
            total_new += 1
        categories_payload.append(category_entry)

    # Advance the checkpoint regardless, so the next backup only looks
    # forward from now - even an empty backup "consumes" the time window.
    org_settings.last_incremental_backup_at = now
    session.commit()

    if total_new == 0:
        return None, 0

    metadata = {
        "backup_id": uuid.uuid4().hex,
        "backup_version": BACKUP_FORMAT_VERSION,
        "backup_type": "incremental",
        "backup_date": now.isoformat(),
        "last_backup_time": checkpoint.isoformat() if checkpoint else None,
    }
    payload = {
        "metadata": metadata,
        "categories": categories_payload,
    }

    timestamp = now.strftime("%Y-%m_%d_%H%M%S")
    filename = f"AutoBackup_{timestamp}.zip"
    dest = os.path.join(backup_controller.auto_dir, filename)
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        zf.writestr("incremental_data.json", json.dumps(payload))

    return dest, total_new


def incremental_backup_if_due(session, category_controller, record_controller,
                                backup_controller, interval_hours: int = 24):
    org_settings = session.query(OrgSettings).first()
    if getattr(org_settings, "backup_enabled", True) is False:
        return None, 0
    if org_settings.last_incremental_backup_at is None:
        result = create_incremental_backup(session, category_controller, record_controller, backup_controller)
    else:
        age_hours = (datetime.now() - org_settings.last_incremental_backup_at).total_seconds() / 3600
        if age_hours >= interval_hours:
            result = create_incremental_backup(session, category_controller, record_controller, backup_controller)
        else:
            result = (None, 0)

    # Cleanup runs every time a new automatic backup is created, per spec.
    if result[0] is not None:
        retention_days = getattr(org_settings, "backup_retention_days", 180)
        backup_controller.purge_old_auto_backups(older_than_days=retention_days)
    return result


def is_incremental_backup(zip_path: str) -> bool:
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            return "incremental_data.json" in zf.namelist()
    except zipfile.BadZipFile:
        return False


def restore_incremental_backup(zip_path: str, category_controller, record_controller):
    """Merges the records from an incremental backup into the CURRENT
    database:
      - If the category has a unique identifier field (e.g. Employee ID),
        an existing record with the same identifier value is UPDATED only
        if the backup's copy is newer (by updated_at), otherwise skipped.
      - Records with no matching existing identifier are inserted as new.
      - Categories that no longer exist (renamed/deleted since the backup
        was made) are reported back as skipped, not silently dropped.
    Never touches login credentials - this format never contained any."""
    with zipfile.ZipFile(zip_path, "r") as zf:
        raw = json.loads(zf.read("incremental_data.json"))

    # Support both the current format ({"metadata": ..., "categories": ...})
    # and the earlier one that had "categories" at the top level.
    categories_data = raw.get("categories", raw) if isinstance(raw, dict) else raw

    categories_by_name = {c.name: c for c in category_controller.list_categories()}
    imported, updated, skipped_records, skipped_categories = 0, 0, 0, []

    for category_entry in categories_data:
        category = categories_by_name.get(category_entry["category_name"])
        if not category:
            skipped_categories.append(category_entry["category_name"])
            continue

        field_by_name = {f.name: f for f in category.fields}
        id_field_name = category_entry.get("identifier_field")
        id_field = field_by_name.get(id_field_name) if id_field_name else None

        # Build a lookup of existing records by identifier value, if this
        # category has one - this is what prevents duplicate imports.
        existing_by_identifier = {}
        if id_field:
            for existing in record_controller.list_records(category.id, page=1, page_size=1_000_000):
                for fv in existing.field_values:
                    if fv.field_id == id_field.id and fv.value:
                        existing_by_identifier[fv.value] = existing
                        break

        for record_entry in category_entry["records"]:
            values = {}
            for field_name, value in record_entry.get("field_values", {}).items():
                field = field_by_name.get(field_name)
                if field:
                    values[field.id] = value

            photo_data = None
            if record_entry.get("photo_base64"):
                try:
                    photo_data = base64.b64decode(record_entry["photo_base64"])
                except (ValueError, TypeError):
                    photo_data = None

            identifier_value = values.get(id_field.id) if id_field else None
            match = existing_by_identifier.get(identifier_value) if identifier_value else None

            if match:
                backup_updated_at = record_entry.get("updated_at")
                if backup_updated_at and backup_updated_at > match.updated_at.isoformat():
                    record_controller.update_record(match, values, photo_data=photo_data,
                                                      changed_by="incremental_restore")
                    updated += 1
                else:
                    skipped_records += 1
            else:
                record_controller.create_record(category, values, photo_data=photo_data,
                                                   changed_by="incremental_restore")
                imported += 1

    return imported, updated, skipped_records, skipped_categories
