from datetime import datetime, timedelta
from sqlalchemy import or_
from app.models.models import Record, FieldValue, FieldDef, Category, RecordHistory, ActivityLog


class RecordController:
    def __init__(self, session):
        self.session = session

    # ---- Create / Read / Update / Delete --------------------------------
    def create_record(self, category: Category, field_values: dict, notes="",
                       photo_path=None, photo_data=None, changed_by="system"):
        record = Record(category_id=category.id, notes=notes,
                         photo_path=photo_path, photo_data=photo_data)
        self.session.add(record)
        self.session.flush()  # get record.id

        for field_id, value in field_values.items():
            self.session.add(FieldValue(record_id=record.id, field_id=field_id, value=str(value)))

        self.session.add(RecordHistory(record_id=record.id, changed_by=changed_by,
                                        change_summary="Record created"))
        self.session.commit()
        return record

    def update_record(self, record: Record, field_values: dict, notes=None,
                       photo_path=None, photo_data=None, changed_by="system"):
        existing = {fv.field_id: fv for fv in record.field_values}
        changes = []
        for field_id, value in field_values.items():
            value = str(value)
            if field_id in existing:
                if existing[field_id].value != value:
                    changes.append(f"field #{field_id}: '{existing[field_id].value}' -> '{value}'")
                    existing[field_id].value = value
            else:
                self.session.add(FieldValue(record_id=record.id, field_id=field_id, value=value))
                changes.append(f"field #{field_id} set to '{value}'")

        if notes is not None:
            record.notes = notes
        if photo_path is not None:
            record.photo_path = photo_path
        if photo_data is not None:
            record.photo_data = photo_data
        record.updated_at = datetime.now()

        if changes:
            self.session.add(RecordHistory(
                record_id=record.id, changed_by=changed_by,
                change_summary="; ".join(changes)[:1000],
            ))
        self.session.commit()
        return record

    def soft_delete(self, record: Record):
        record.is_deleted = True
        record.deleted_at = datetime.now()
        self.session.commit()

    def restore(self, record: Record):
        record.is_deleted = False
        record.deleted_at = None
        self.session.commit()

    def _delete_record_files(self, record: Record):
        """Removes the photo file and any attached document files from disk.
        Never raises - a missing/already-gone file is fine, we're deleting
        anyway."""
        import os
        if record.photo_path:
            try:
                if os.path.exists(record.photo_path):
                    os.remove(record.photo_path)
            except OSError:
                pass
        for attachment in record.attachments:
            try:
                if attachment.file_path and os.path.exists(attachment.file_path):
                    os.remove(attachment.file_path)
            except OSError:
                pass

    def permanently_delete(self, record: Record):
        """Removes the record AND its associated photo/document files from
        disk - after this, nothing about the record is recoverable."""
        self._delete_record_files(record)
        self.session.delete(record)
        self.session.commit()

    def permanently_delete_many(self, records: list[Record]):
        for record in records:
            self._delete_record_files(record)
            self.session.delete(record)
        self.session.commit()

    def empty_recycle_bin(self, older_than_days=10):
        cutoff = datetime.now() - timedelta(days=older_than_days)
        old = (self.session.query(Record)
               .filter(Record.is_deleted.is_(True), Record.deleted_at < cutoff).all())
        for r in old:
            self._delete_record_files(r)
            self.session.delete(r)
        self.session.commit()
        return len(old)

    def list_all_deleted(self):
        """All soft-deleted records across every category, newest-deleted first.
        Used by the Recycle Bin screen."""
        return (self.session.query(Record)
                .filter(Record.is_deleted.is_(True))
                .order_by(Record.deleted_at.desc()).all())

    def duplicate_record(self, record: Record):
        values = {fv.field_id: fv.value for fv in record.field_values}
        return self.create_record(record.category, values, notes=record.notes)

    def bulk_delete(self, record_ids: list[int]):
        (self.session.query(Record).filter(Record.id.in_(record_ids))
         .update({Record.is_deleted: True, Record.deleted_at: datetime.now()},
                 synchronize_session=False))
        self.session.commit()

    def toggle_favorite(self, record: Record):
        record.is_favorite = not record.is_favorite
        self.session.commit()

    def toggle_pin(self, record: Record):
        record.is_pinned = not record.is_pinned
        self.session.commit()

    # ---- Listing / Search -------------------------------------------------
    def list_records(self, category_id: int, include_deleted=False, page=1, page_size=50):
        q = self.session.query(Record).filter(Record.category_id == category_id)
        if not include_deleted:
            q = q.filter(Record.is_deleted.is_(False))
        q = q.order_by(Record.is_pinned.desc(), Record.updated_at.desc())
        return q.offset((page - 1) * page_size).limit(page_size).all()

    def count_records(self, category_id: int, include_deleted=False):
        q = self.session.query(Record).filter(Record.category_id == category_id)
        if not include_deleted:
            q = q.filter(Record.is_deleted.is_(False))
        return q.count()

    def search(self, category_id: int, query: str, page=1, page_size=50):
        """Instant search across all field values + notes for a category."""
        like = f"%{query}%"
        q = (self.session.query(Record)
             .join(FieldValue, FieldValue.record_id == Record.id, isouter=True)
             .filter(Record.category_id == category_id, Record.is_deleted.is_(False))
             .filter(or_(FieldValue.value.ilike(like), Record.notes.ilike(like)))
             .distinct())
        total = q.count()
        results = q.offset((page - 1) * page_size).limit(page_size).all()
        return results, total

    def advanced_search(self, category_id: int, criteria: dict, page=1, page_size=50):
        """criteria: {field_id: value_substring}"""
        q = self.session.query(Record).filter(
            Record.category_id == category_id, Record.is_deleted.is_(False))
        for field_id, value in criteria.items():
            q = q.filter(Record.field_values.any(
                FieldValue.field_id == field_id, FieldValue.value.ilike(f"%{value}%")))
        total = q.count()
        return q.offset((page - 1) * page_size).limit(page_size).all(), total

    # ---- Dashboard stats ---------------------------------------------------
    def dashboard_stats(self):
        total_records = self.session.query(Record).filter(Record.is_deleted.is_(False)).count()
        total_categories = self.session.query(Category).count()
        recent = (self.session.query(Record).filter(Record.is_deleted.is_(False))
                  .order_by(Record.created_at.desc()).limit(10).all())
        per_category = {}
        for cat in self.session.query(Category).all():
            per_category[cat.name] = self.count_records(cat.id)
        return {
            "total_records": total_records,
            "total_categories": total_categories,
            "recent_records": recent,
            "per_category": per_category,
        }
