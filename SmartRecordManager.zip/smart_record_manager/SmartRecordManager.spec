# -*- mode: python ; coding: utf-8 -*-
#
# PyInstaller build spec for Smart Record Manager.
#
# This packages the whole app - Python interpreter, PySide6/Qt,
# SQLAlchemy, openpyxl, reportlab, Pillow, and all of the app's own code -
# into a single SmartRecordManager.exe. Customers only need this one file;
# they do NOT need Python (or anything from requirements.txt) installed.
#
# Build it once (on a Windows machine, with the project's requirements.txt
# installed) by double-clicking BUILD_EXE.bat, or manually with:
#   pyinstaller SmartRecordManager.spec
#
# The result is dist/SmartRecordManager.exe - copy that single file
# anywhere and run it. On first launch it creates data/ and backups/
# folders next to itself, exactly like the source version does.

import os

block_cipher = None
PROJECT_ROOT = os.path.abspath(os.path.dirname(SPEC))

a = Analysis(
    ['app/main.py'],
    pathex=[PROJECT_ROOT],
    binaries=[],
    datas=[
        ('resources', 'resources'),
    ],
    hiddenimports=[
        'PySide6.QtCore',
        'PySide6.QtGui',
        'PySide6.QtWidgets',
        'sqlalchemy.sql.default_comparator',
        'openpyxl',
        'reportlab',
        'PIL',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    cipher=block_cipher,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='SmartRecordManager',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=os.path.join(PROJECT_ROOT, 'resources', 'icons', 'app_icon.ico'),
)
