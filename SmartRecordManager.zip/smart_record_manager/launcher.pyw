"""
Smart Record Manager - Launcher
================================
Double-clicked via RUN_APP.bat (or directly with pythonw launcher.pyw).

- No visible console ever, on first-time setup OR regular launches
- First run: centered branded panel with a real, determinate progress bar
  that advances as each component installs (not a generic spinner)
- Every run after that: launches the app almost immediately with a very
  brief panel, since setup is already done

Implementation notes (why it's built this way):
- `python -m venv --without-pip` + a separate `ensurepip` call avoids a
  known Windows quirk where venv's *internal* pip-bootstrap step spawns a
  nested console-subsystem process that briefly flashes a black terminal
  window, even though our own subprocess calls use CREATE_NO_WINDOW.
- Each requirement is installed one at a time so the progress bar reflects
  real installation progress instead of a fake/indeterminate spinner.
- Uses only the Python standard library (tkinter), so it works even before
  any dependencies are installed on a brand-new machine.
"""
import os
import sys
import subprocess
import threading
import tkinter as tk
from tkinter import ttk

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
VENV_DIR = os.path.join(PROJECT_ROOT, "venv")
REQUIREMENTS = os.path.join(PROJECT_ROOT, "requirements.txt")

IS_WINDOWS = os.name == "nt"
CREATE_NO_WINDOW = 0x08000000 if IS_WINDOWS else 0
ACCENT = "#2563EB"

if IS_WINDOWS:
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)  # fixes off-center/blurry splash on scaled displays
    except Exception:
        pass


def venv_python():
    if IS_WINDOWS:
        return os.path.join(VENV_DIR, "Scripts", "python.exe")
    return os.path.join(VENV_DIR, "bin", "python")


def venv_pythonw():
    if IS_WINDOWS:
        pw = os.path.join(VENV_DIR, "Scripts", "pythonw.exe")
        return pw if os.path.exists(pw) else venv_python()
    return venv_python()


def _run_hidden(cmd, **kwargs):
    return subprocess.run(
        cmd, check=True, creationflags=CREATE_NO_WINDOW,
        stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, **kwargs
    )


def read_requirements():
    packages = []
    if os.path.exists(REQUIREMENTS):
        with open(REQUIREMENTS, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    packages.append(line)
    return packages


def build_splash(determinate: bool):
    root = tk.Tk()
    root.overrideredirect(True)
    width, height = 440, 190
    root.attributes("-alpha", 0.0)  # avoid a visible flash at the default (0,0) position
    root.update_idletasks()
    screen_w = root.winfo_screenwidth()
    screen_h = root.winfo_screenheight()
    x = (screen_w - width) // 2
    y = (screen_h - height) // 2
    root.geometry(f"{width}x{height}+{x}+{y}")
    root.configure(bg=ACCENT)
    try:
        root.attributes("-topmost", True)
    except tk.TclError:
        pass

    tk.Label(root, text="Smart Record Manager", fg="white", bg=ACCENT,
             font=("Segoe UI", 15, "bold")).pack(pady=(28, 6))
    status_label = tk.Label(root, text="", fg="#DCE6FF", bg=ACCENT, font=("Segoe UI", 10))
    status_label.pack()

    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass
    style.configure("Splash.Horizontal.TProgressbar", troughcolor="#1E4FD1",
                     background="white", thickness=8)
    mode = "determinate" if determinate else "indeterminate"
    progress = ttk.Progressbar(root, mode=mode, length=340,
                                style="Splash.Horizontal.TProgressbar")
    progress.pack(pady=18)
    if determinate:
        progress["maximum"] = 100
        progress["value"] = 0
    else:
        progress.start(10)

    percent_label = tk.Label(root, text="", fg="#DCE6FF", bg=ACCENT, font=("Segoe UI", 8))
    percent_label.pack()

    root.attributes("-alpha", 1.0)  # reveal only once it's correctly centered
    return root, status_label, progress, percent_label


def run_first_time_setup(root, status_label, progress, percent_label):
    packages = read_requirements()
    total_steps = 2 + len(packages)  # venv create + pip bootstrap + each package
    done = 0

    def advance(message):
        nonlocal done
        done += 1
        pct = int((done / total_steps) * 100)
        root.after(0, lambda: (
            status_label.config(text=message),
            progress.config(value=pct),
            percent_label.config(text=f"{pct}%"),
        ))

    root.after(0, lambda: status_label.config(text="Creating environment..."))
    _run_hidden([sys.executable, "-m", "venv", "--without-pip", VENV_DIR])
    advance("Preparing package manager...")

    _run_hidden([venv_python(), "-m", "ensurepip", "--upgrade"])
    advance(f"Installed 2 / {total_steps} components...")

    for pkg in packages:
        name = pkg.split(">=")[0].split("==")[0].strip()
        root.after(0, lambda n=name: status_label.config(text=f"Installing {n}..."))
        _run_hidden([venv_python(), "-m", "pip", "install", "-q", pkg], cwd=PROJECT_ROOT)
        advance(f"Installed {done + 1} / {total_steps} components...")


def run():
    first_run = not os.path.exists(venv_python())
    root, status_label, progress, percent_label = build_splash(determinate=first_run)
    error_holder = {}

    if not first_run:
        status_label.config(text="Opening app...")

    def worker():
        try:
            if first_run:
                run_first_time_setup(root, status_label, progress, percent_label)

            root.after(0, lambda: status_label.config(text="Launching Smart Record Manager..."))
            subprocess.Popen(
                [venv_pythonw(), "-m", "app.main"], cwd=PROJECT_ROOT,
                creationflags=CREATE_NO_WINDOW,
            )
        except subprocess.CalledProcessError as e:
            error_holder["error"] = (
                "Setup failed. Please check your internet connection and try again.\n\n"
                f"Details: {e}"
            )
        except Exception as e:
            error_holder["error"] = str(e)
        finally:
            # Regular launches close almost instantly; first-run setup lingers
            # briefly so the 100% state is visible before disappearing.
            delay = 500 if first_run else 150
            root.after(delay, root.destroy)

    threading.Thread(target=worker, daemon=True).start()
    root.mainloop()

    if error_holder.get("error"):
        err_root = tk.Tk()
        err_root.title("Smart Record Manager - Setup Error")
        err_root.geometry("440x200")
        tk.Label(err_root, text="Something went wrong", font=("Segoe UI", 12, "bold")).pack(pady=(16, 6))
        tk.Message(err_root, text=error_holder["error"], width=380).pack(pady=6)
        tk.Button(err_root, text="Close", command=err_root.destroy).pack(pady=10)
        err_root.mainloop()


if __name__ == "__main__":
    run()
