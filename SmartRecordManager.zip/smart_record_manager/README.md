# Smart Record Manager

A modern desktop record-management app for **any organization** — schools,
colleges, offices, hospitals, libraries, NGOs. Define your own categories
(Students, Patients, Employees, Books...) with **unlimited custom fields**,
no code changes required.

## What's included in this build

- Dashboard with live stats (total records, categories, recent activity)
- Full record CRUD: add / edit (single record at a time, with a Back button) /
  delete (one or more at once) / pin to top of its category
- **Dynamic fields**: admin can add/rename/delete/retype fields per category
  at runtime (text, number, date, email, phone, dropdown, checkbox, image,
  file, long text) — changes appear immediately, no restart needed
- Multiple categories, each with its own field set
- Instant search + sortable table columns, with photo thumbnails
- Recycle Bin: view/restore/permanently-delete soft-deleted records, with
  automatic purge after 10 days
- Role-based auth: Admin / Staff / Viewer, password hashing (PBKDF2)
- User management: add, rename, delete (requires the acting admin's own
  password, and always keeps at least one account), per-user password change
- Import/Export: CSV, Excel (.xlsx), JSON, PDF
- Manual + automatic backup/restore (SQLite file-based), with an in-app
  Restore Backup screen and support for pointing backups at a cloud-synced
  folder (Google Drive/OneDrive/Dropbox)
- Light/Dark theme, custom accent color, adjustable font size, org name and
  a properly-fit square logo in the sidebar
- **Photo is now optional per category** — toggle "Use a photo for this
  category" in Manage Categories. When enabled, the photo appears first in
  both the Add/Edit form and the record list table (as the first column);
  when disabled, no photo controls or column appear at all for that
  category, and exports skip the Photo column too
- Photo field for every record: **Upload Photo** (choose an existing image
  file) or **📷 Take Photo** (live camera capture). Every photo is
  automatically resized/compressed (max 900px, JPEG quality 82 — still
  clearly visible, ~10-20x smaller than a raw camera photo) and copied into
  `data/photos/`, with the same compressed copy also saved inside the
  database itself
- **Photo files auto-delete after 30 days** to keep disk usage predictable
  over years of use — but the app still shows and can **⬇ Download** the
  photo afterward, since the database keeps its own compressed copy. The
  download option only appears when editing a record that actually has a photo
- **Professional backup system**:
  - Automatic backups are **incremental** (only records added/updated since
    the last one) and live in `backups/Auto/`
  - **Menu → Backup → Backup All Records** makes a complete archive in
    `backups/Manual/` — restoring one replaces everything with that snapshot
  - **Backups NEVER contain login credentials** — verified: the `users`
    table is stripped before every backup, and restoring any backup always
    re-applies whatever username/password were active immediately before
    the restore, regardless of how old the backup is
  - Restoring an automatic (incremental) backup **merges** records using a
    unique identifier field (Employee ID, Roll Number, etc. — whichever
    field is marked unique or looks ID-like) — updates only if the backup's
    copy is newer, never duplicates
  - **Menu → Backup → Backup Settings**: enable/disable automatic backups,
    backup folder, frequency, compression, and auto-delete period (default
    6 months) — auto-delete only ever removes *automatic* backups, never
    manual ones, and always keeps at least the newest automatic backup
- **Import CSV and Import Excel removed** (Export Excel/PDF/JSON remain)
- **Recycle Bin**: Permanent Delete now also removes the associated photo
  file (and any document attachments) from disk, not just the database row
- **Table display fixed**: column headers no longer get cut off (e.g. "Roll
  Numbe" → "Roll Number") — tables now scroll horizontally instead of
  squeezing columns to fit
- Excel and PDF exports now **embed each record's photo**, not just the
  written field values
- Edit / Delete / Pin picker popups now include a **search box** to filter
  long lists
- Excel exports: photo now fits its cell cleanly (sized and the
  column/row dimensions matched so it doesn't overflow or leave gaps)
- **CSV export removed** from the Menu (Excel/PDF/JSON remain; CSV import
  still works)
- **Single-instance protection**: opening the app a second time (from the
  folder, a shortcut, or anywhere else) while it's already running shows
  "Smart Record Manager is already open" instead of launching a second
  window. This directly prevents the data corruption/lost-changes risk of
  two windows both writing to the same database at once.
- Opens maximized on launch
- SQLite by default; swap one connection string to move to MySQL/PostgreSQL
- No visible CMD/console window on first-time setup or regular launches —
  a small branded loading panel shows instead (see "Launching the app" below)

## ⚠️ Security note: plain-text credentials backup

At your request, every username and password is also written to
`data/user_credentials_backup.txt` in **plain, unencrypted text**, so an
admin can look up a forgotten password directly. This is separate from the
app's actual login system, which never stores raw passwords (only salted
PBKDF2 hashes) — the backup file exists purely for convenience.

**Anyone who can open that file can log in as any user in it.** Keep the
`data` folder private, don't back it up to shared drives, and don't send it
to anyone. If that risk isn't acceptable for your use case, tell me and I
can remove this feature or replace it with an admin-only reset flow instead.

## Not yet included (clean extension points, not started)

QR codes, barcodes, printable ID cards/labels, reminder notifications
(birthdays/fees), keyboard shortcuts, drag-and-drop field reordering.

## Requirements

- Python 3.10+
- See `requirements.txt`

## Launching the app (Windows)

Just double-click **`RUN_APP.bat`**. You will not see a CMD/console window —
instead a small centered "Smart Record Manager" panel appears:

- **First time only**: shows a real progress bar that advances as each
  component installs ("Installing PySide6...", "Installing SQLAlchemy...",
  etc. — not a generic spinner), then opens the app
- **Every time after**: appears briefly ("Opening app...") and the app
  window appears, maximized

If Windows shows a "Windows protected your PC" SmartScreen warning (common
for unsigned scripts), click **More info** → **Run anyway**.

### If regular launches still feel slow

Two things outside the app's own code usually cause this, and both are
worth checking if it's taking more than a few seconds after first-time setup:

1. **Antivirus/Windows Defender scanning.** Every time a new `.exe`/Python
   process starts from a folder Defender hasn't "trusted" yet, it can
   re-scan it — this is the most common cause of a 10-30 second delay on a
   fresh setup. Add the `smart_record_manager` folder to Defender's
   exclusion list (Windows Security → Virus & threat protection →
   Exclusions) to remove this delay entirely.
2. **Location matters.** Running out of `Downloads` (which Defender/SmartScreen
   treats as less trusted) is typically slower than moving the whole folder
   to somewhere like `C:\SmartRecordManager` first.

Qt itself (the UI library) normally starts in 1-3 seconds — if it's much
slower than that even after the two steps above, let me know your system
specs and I can help track down the bottleneck further.

### Manual / command-line setup (optional, for developers)

```bash
cd smart_record_manager
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python -m app.main
```

First run creates `data/records.db` automatically with:
- A default admin account (see `data/user_credentials_backup.txt` after
  first run for the exact username/password — it's no longer shown on the
  login screen itself)
- Two example categories pre-loaded: **Students** and **Employees**

### Optional: load sample data to see it working immediately

```bash
python -m scripts.seed_sample_data
```

## Project structure

```
smart_record_manager/
├── app/
│   ├── main.py                  # entry point
│   ├── models/
│   │   ├── models.py            # SQLAlchemy schema (dynamic-field design)
│   │   └── bootstrap.py         # first-run seeding (admin user, categories)
│   ├── controllers/             # business logic, no UI code
│   │   ├── auth_controller.py
│   │   ├── category_controller.py
│   │   ├── record_controller.py
│   │   ├── io_controller.py     # import/export
│   │   └── backup_controller.py
│   ├── ui/                      # PySide6 views
│   │   ├── main_window.py
│   │   ├── login_dialog.py
│   │   ├── dashboard_widget.py
│   │   ├── record_list_widget.py
│   │   ├── record_form_dialog.py
│   │   ├── category_manager_dialog.py
│   │   ├── settings_dialog.py
│   │   └── styles.py            # light/dark QSS
│   └── utils/
│       └── security.py          # password hashing
├── scripts/
│   └── seed_sample_data.py
├── data/                        # records.db lives here (gitignored)
├── backups/                     # .db backups (gitignored)
└── requirements.txt
```

## How the "unlimited custom fields" system works

Rather than a fixed table per record type, each `Category` (Students,
Patients, ...) owns a list of `FieldDef` rows (name + type + required/unique
+ dropdown options). Each `Record` stores its data as `FieldValue` rows keyed
to those field definitions. This means:

- Adding/renaming/deleting a field is a data change, not a schema migration
- The record form (`record_form_dialog.py`) builds its inputs by reading the
  category's field list and rendering the right widget per `field_type`
- The same code path works identically for a school, a hospital, or a library

Adding, renaming, or deleting a category or field now takes effect
immediately in the sidebar and table — no restart needed.

## Migrating from SQLite to MySQL/PostgreSQL

Only one line needs to change, in `app/models/models.py`:

```python
def get_engine(db_path: str):
    return create_engine(f"sqlite:///{db_path}")
```

Replace with, e.g.:

```python
return create_engine("postgresql+psycopg2://user:password@host/dbname")
# or
return create_engine("mysql+pymysql://user:password@host/dbname")
```

Install the matching driver (`psycopg2-binary` or `pymysql`) and run once —
`Base.metadata.create_all(engine)` in `init_db()` creates all tables on the
new database automatically.

## Setting a custom app icon

1. Get your logo as a square image (PNG, at least 256x256).
2. Convert it to `.ico` format — Windows needs this for the taskbar/exe icon,
   a plain `.png` won't show up as the app icon. Easiest ways:
   - Free online converter: search "png to ico converter" (e.g. icoconvert.com,
     convertio.co) — upload your PNG, download the `.ico`
   - Or, if you have Pillow installed: `python -c "from PIL import Image; Image.open('logo.png').save('app_icon.ico', sizes=[(16,16),(32,32),(48,48),(256,256)])"`
3. Place the resulting file at:
   ```
   smart_record_manager/resources/icons/app_icon.ico
   ```
4. Restart the app (`RUN_APP.bat`) — the window/taskbar icon picks it up
   automatically, no code changes needed.
5. **If you build a standalone .exe with PyInstaller** (see below), also
   pass `--icon` pointing at the same file so the .exe file itself shows
   your icon in File Explorer, not just while it's running.

If no icon file is present, the app just uses Qt's default icon — nothing breaks.

## Building a standalone executable for customers (no Python needed on their PC)

This is the recommended way to hand the app to customers whose computers
don't have Python installed. It packages Python itself, PySide6/Qt, and
every other dependency into one `SmartRecordManager.exe` file.

**Easiest way:** double-click **`BUILD_EXE.bat`** on a Windows PC that has
Python installed (this is a one-time build step for *you*, not something
customers need to do). It creates a throwaway `build_venv`, installs
`requirements.txt` into it, and runs PyInstaller using the included
`SmartRecordManager.spec`. When it finishes, your distributable file is at:

```
dist\SmartRecordManager.exe
```

Copy that single `.exe` to a folder (e.g. a USB drive or a zip you send
customers) — that's the whole app. Customers just double-click it; no
Python, no `pip install`, no internet connection required. On first launch
it creates `data\` and `backups\` folders right next to the `.exe`, exactly
like the source version does, so keep the `.exe` in a folder the customer
can write to (Desktop or `C:\SmartRecordManager` are good choices — avoid
read-only locations).

**Manual equivalent**, if you'd rather not use the `.bat`/`.spec` files:

```bash
pip install -r requirements.txt
pyinstaller --name "SmartRecordManager" \
            --windowed \
            --onefile \
            --icon "resources/icons/app_icon.ico" \
            --add-data "resources;resources" \
            app/main.py
```

- `--icon` sets the icon shown on the .exe file itself in File Explorer (omit
  this flag if you haven't added an icon yet — see "Setting a custom app icon" above)
- `--windowed` hides the console window (remove it while debugging so you can
  see error output)
- On Windows, use `--add-data "resources;resources"` (semicolon, not colon);
  on macOS/Linux use a colon instead
- The executable will appear in `dist/SmartRecordManager.exe`
- Data/backups/resources paths are already frozen-exe-safe (see
  `app/utils/paths.py`) — they resolve to the folder containing the `.exe`
  when running as a built executable, and to the project folder as before
  when running from source, so nothing about day-to-day usage changes
  either way.

## Security notes

- Passwords are hashed with PBKDF2-HMAC-SHA256 (200,000 iterations) + random
  salt — never stored in plaintext
- SQL injection is not a concern for user-entered data since all queries go
  through SQLAlchemy's parameterized query builder (no raw string SQL
  anywhere in the codebase)
- Change the default admin password immediately after first login
