@echo off
cd /d "%~dp0"

where pythonw >nul 2>nul
if %errorlevel%==0 (
    start "" pythonw "launcher.pyw"
) else (
    start "" python "launcher.pyw"
)
exit
