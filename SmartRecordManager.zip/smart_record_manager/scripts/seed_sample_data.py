"""
Populates the Students and Employees categories with sample records so you
can see the app working immediately, instead of starting from an empty table.

Run with:  python -m scripts.seed_sample_data   (from the project root)
"""
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.models.bootstrap import bootstrap_database
from app.controllers.record_controller import RecordController
from app.models.models import Category

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
DB_PATH = os.path.join(DATA_DIR, "records.db")

FIRST_NAMES = ["Aarav", "Priya", "Rohan", "Ananya", "Vikram", "Sneha", "Karan", "Isha"]
LAST_NAMES = ["Sharma", "Verma", "Patel", "Reddy", "Iyer", "Nair", "Gupta", "Singh"]
BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"]
DEPARTMENTS = ["Accounts", "HR", "Sales", "IT", "Operations"]


def seed():
    os.makedirs(DATA_DIR, exist_ok=True)
    engine, Session = bootstrap_database(DB_PATH)
    session = Session()
    rc = RecordController(session)

    students = session.query(Category).filter_by(name="Students").first()
    employees = session.query(Category).filter_by(name="Employees").first()

    if students and rc.count_records(students.id) == 0:
        field_by_name = {f.name: f.id for f in students.fields}
        for i in range(1, 21):
            name = f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"
            values = {
                field_by_name["Name"]: name,
                field_by_name["Roll Number"]: f"S{1000 + i}",
                field_by_name["Class"]: str(random.randint(6, 12)),
                field_by_name["Section"]: random.choice(["A", "B", "C"]),
                field_by_name["Age"]: str(random.randint(11, 18)),
                field_by_name["Blood Group"]: random.choice(BLOOD_GROUPS),
            }
            rc.create_record(students, values, changed_by="seed_script")
        print(f"Seeded 20 sample student records.")

    if employees and rc.count_records(employees.id) == 0:
        field_by_name = {f.name: f.id for f in employees.fields}
        for i in range(1, 11):
            name = f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"
            values = {
                field_by_name["Name"]: name,
                field_by_name["Employee ID"]: f"E{2000 + i}",
                field_by_name["Department"]: random.choice(DEPARTMENTS),
                field_by_name["Salary"]: str(random.randint(30000, 90000)),
            }
            rc.create_record(employees, values, changed_by="seed_script")
        print(f"Seeded 10 sample employee records.")

    session.close()
    print("Done. Run the app with: python -m app.main")


if __name__ == "__main__":
    seed()
