@echo off
REM ============================================================
REM  Smart Record Manager - build the standalone customer .exe
REM ============================================================
REM  Run this ONCE, on a Windows PC that has Python installed.
REM  It installs the build requirements into a local venv, then
REM  runs PyInstaller to produce:
REM
REM      dist\SmartRecordManager.exe
REM
REM  That single file is what you hand to customers. It contains
REM  Python and every library the app needs, so it runs on any
REM  Windows PC even if Python is NOT installed there.
REM ============================================================
cd /d "%~dp0"

where python >nul 2>nul
if not %errorlevel%==0 (
    echo Python was not found on this PC. Install Python 3.10+ from
    echo https://python.org, then run this script again.
    pause
    exit /b 1
)

echo [1/4] Creating a clean build environment...
if not exist build_venv (
    python -m venv build_venv
)

echo [2/4] Installing app + build requirements...
build_venv\Scripts\python.exe -m pip install --upgrade pip -q
build_venv\Scripts\python.exe -m pip install -r requirements.txt -q

echo [3/4] Building SmartRecordManager.exe with PyInstaller...
build_venv\Scripts\python.exe -m PyInstaller --noconfirm --clean SmartRecordManager.spec

echo [4/4] Done.
echo.
echo Your standalone app is at: dist\SmartRecordManager.exe
echo Copy that one file to a folder and share it with customers -
echo they do NOT need Python installed to run it.
echo.
pause
